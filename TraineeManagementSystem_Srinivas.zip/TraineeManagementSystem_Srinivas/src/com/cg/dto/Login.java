package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="Login")
public class Login {
@Id
@NotEmpty(message="UserName is Mandatory")
@Column
private String username;
@NotEmpty(message="Password is Mandstory")
@Size(min=2,max=10,message="Min 2 and Max 10 Char are allowed")
@Column
private String password;
@Override
public String toString() {
	return "Login [username=" + username + ", password=" + password + "]";
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Login(String username, String password) {
	super();
	this.username = username;
	this.password = password;
}
public Login() {
	super();
	
}

}
