package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.cg.dao.TraineeDao;
import com.cg.dto.Login;
import com.cg.dto.Trainee;
@Service("service")
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	 TraineeDao dao;
	 
	

	public TraineeDao getDao() {
		return dao;
	}

	public void setDao(TraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean isUserExist(String unm) {
	
		return dao.isUserExist(unm);
	}

	@Override
	public boolean isValid(Login log) {
		
		return dao.isValid(log);
	}

	@Override
	public void addTrainee(Trainee trainee) {
	dao.addTrainee(trainee);
	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		dao.modifyTrainee(trainee);
	}

	@Override
	public void deleteTrainee(int userId) {
		dao.deleteTrainee(userId);
	}

	@Override
	public Trainee retriveTrainee(int userId) {
		
		return dao.retriveTrainee(userId);
	}

	@Override
	public ArrayList<Trainee> retriveAllTrainees() {
		
		return dao.retriveAllTrainees();
	}
	
	
	
	
	
	
}
