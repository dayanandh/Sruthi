package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;
import com.cg.dto.Trainee;
import com.cg.service.TraineeService;


@Controller
public class TraineeController {
	@Autowired
	TraineeService service;
	ArrayList<String> LocList=null;
	ArrayList<String> DomList=null;

	public TraineeService getService() {
		return service;
	}
	public void setService(TraineeService service) {
		this.service = service;
	}
	@RequestMapping(value="/LoginPage",method=RequestMethod.GET)
	public String disploginPage(Model model){

		Login lg=new Login();
		model.addAttribute("loginUser",lg);
		return "login";
	}
	@RequestMapping(value="/ValidateUser",method=RequestMethod.GET)
	public String ValidateLogin(
			@Valid
			@ModelAttribute("loginUser")Login lgg,
			BindingResult result,
			Model model){
		String target="";
		if(result.hasErrors()){
			target="login";
		}
		else{
			String un=lgg.getUsername();

			if(service.isUserExist(un))
			{
				if(service.isValid(lgg)){
					target="tmsindex";
				}

				else{
					String msg="Password is Incorrect";
					model.addAttribute("ErrorMsgObj",msg);
					target="error";

				}
			}
			else{
				String msg="Not a Authorized Person";
				model.addAttribute("ErrorMsgObj",msg);
				target="error";
			}
		}


		return target;

	}

	@RequestMapping(value="/AddATrainee",method=RequestMethod.GET)
	public String AddTraineePage(Model model){

		LocList=new ArrayList<String>();
		DomList=new ArrayList<String>();
		LocList.add("Chennai");
		LocList.add("Pune");
		LocList.add("Banglore");
		LocList.add("Mumbai");

		DomList.add("C");
		DomList.add("JEE");
		DomList.add("#C");
		DomList.add("Ruby");
		DomList.add("Phython");
		DomList.add("Oracle");
		DomList.add("C++");		

		Trainee t=new Trainee();
		model.addAttribute("trainee",t);
		model.addAttribute("DomList",DomList);
		model.addAttribute("LocList",LocList);
		return "addtrainee";
	}

	@RequestMapping(value="/insertTraineeDetails",method=RequestMethod.GET)
	public String addUserDetails(
			@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,
			Model model){
		service.addTrainee(trainee);
		String dispmsg="Trainee Added Successfully";
		model.addAttribute("msg",dispmsg);
		return "success";


	}
	@RequestMapping(value="/RetriveAllTrainee",method=RequestMethod.GET)
	public String dispUserListPage(Model model)
	{

		ArrayList<Trainee> list=service.retriveAllTrainees();
		model.addAttribute("traineeListObj",list);
		return "retriveall";

	}
	@RequestMapping(value="/ModifyATrainee",method=RequestMethod.GET)
	public String updatePage(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model){
		
		
		return "update";
	}
	
	
	
	
	@RequestMapping(value="/modifyTrainee",method=RequestMethod.GET)
	public String updatedPage(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model,@RequestParam("traineeId")  String traineeId) {
		int tId=Integer.parseInt(traineeId);
		
		Trainee tee=service.retriveTrainee(tId);
		if(tee==null){
			String Vmsg="Enter a Valid Id";
			model.addAttribute("Vmsg",Vmsg);
		return"update";	
		}
		else{
		trainee.setTraineeId(tee.getTraineeId());
		trainee.setTraineeName(tee.getTraineeName());
		trainee.setTraineeLocation(tee.getTraineeLocation());
		trainee.setTraineeDomain(tee.getTraineeDomain());
		
		
		model.addAttribute("updateObj",trainee);
		return "update";
		}
	}
	@RequestMapping(value="/updated",method=RequestMethod.GET)
	public String updatedd(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model) {
		service.modifyTrainee(trainee);
		String dispmsg="Trainee Updated Successfully";
		model.addAttribute("msg",dispmsg);
		return "success";

	}
	@RequestMapping(value="/DeleteATrainee",method=RequestMethod.GET)
	public String deletePage(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model){
		
		
		return "delete";
	}
	
	
	
	
	@RequestMapping(value="/deleteTrainee",method=RequestMethod.GET)
	public String dispEditPage(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model,@RequestParam("traineeId")  String traineeId) {
		int tId=Integer.parseInt(traineeId);
		Trainee tee=service.retriveTrainee(tId);
		if(tee==null){
			String Vmsg="Enter a Valid Id";
			model.addAttribute("Vmsg",Vmsg);
		return"delete";	
		}
		else{
		trainee.setTraineeId(tee.getTraineeId());
		trainee.setTraineeName(tee.getTraineeName());
		trainee.setTraineeLocation(tee.getTraineeLocation());
		trainee.setTraineeDomain(tee.getTraineeDomain());
		
		model.addAttribute("trainee",trainee);
		return "delete";
		}

	}
	@RequestMapping(value="/deleted",method=RequestMethod.GET)
	public String deleted(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model,@RequestParam("tid")  int tid) {
	
		service.deleteTrainee(tid);
		String dispmsg="Trainee Deleted Successfully";
		model.addAttribute("msg",dispmsg);
		return "success";

	}
	@RequestMapping(value="/RetriveATrainee",method=RequestMethod.GET)
	public String retrive(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model){
		
		
		return "retrive";
	}
	
	
	
	
	@RequestMapping(value="/RetriveTrainee",method=RequestMethod.GET)
	public String retrivedPage(@Valid
			@ModelAttribute("trainee")Trainee trainee,
			BindingResult result,Model model,@RequestParam("traineeId")  String traineeId) {
		int tId=Integer.parseInt(traineeId);
		Trainee tee=service.retriveTrainee(tId);
		if(tee==null){
			String Vmsg="Enter a Valid Id";
			model.addAttribute("Vmsg",Vmsg);
		return"retrive";	
		}
		else{
		trainee.setTraineeId(tee.getTraineeId());
		trainee.setTraineeName(tee.getTraineeName());
		trainee.setTraineeLocation(tee.getTraineeLocation());
		trainee.setTraineeDomain(tee.getTraineeDomain());
		
		model.addAttribute("updateObj",trainee);
		return "retrive";
		}
	}

}
