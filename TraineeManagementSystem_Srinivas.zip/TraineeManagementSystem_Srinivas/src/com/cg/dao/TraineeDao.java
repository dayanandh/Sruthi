package com.cg.dao;

import java.util.ArrayList;



import com.cg.dto.Login;
import com.cg.dto.Trainee;



public interface TraineeDao {
	public boolean isUserExist(String unm);
	public boolean isValid(Login log);
	public void addTrainee(Trainee trainee);
	public void modifyTrainee(Trainee trainee);
	public void deleteTrainee(int userId);
	public Trainee retriveTrainee(int userId);
	public ArrayList<Trainee> retriveAllTrainees();
	
}
