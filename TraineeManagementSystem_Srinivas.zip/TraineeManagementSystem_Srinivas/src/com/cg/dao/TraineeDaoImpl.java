package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;



import com.cg.dto.Login;
import com.cg.dto.Trainee;



@Repository("daoi")
@Transactional
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	private EntityManager em;

	

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public boolean isUserExist(String unm) {
		Login log=em.find(Login.class,unm);
		if(log!=null){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public boolean isValid(Login log) {
		Login lg=em.find(Login.class,log.getUsername());
		if(log.getPassword().equalsIgnoreCase(lg.getPassword())){
			return true;
		}
		else{


			return false;
		}
	}

	@Override
	public void addTrainee(Trainee trainee) {


		em.persist(trainee);


	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		Trainee updtrainee=em.find(Trainee.class,trainee.getTraineeId());
		updtrainee.setTraineeName(trainee.getTraineeName());
		updtrainee.setTraineeLocation(trainee.getTraineeLocation());
		updtrainee.setTraineeDomain(trainee.getTraineeDomain());


	}

	@Override
	public void deleteTrainee(int userId) {
		Trainee deltrainee=em.find(Trainee.class,userId);
		em.remove(deltrainee);

	}

	@Override
	public Trainee retriveTrainee(int userId) {
		Trainee trainee=em.find(Trainee.class,userId);
		return trainee;
	}

	@Override
	public ArrayList<Trainee> retriveAllTrainees() {
		String qry="SELECT tra from Trainee tra";
		TypedQuery<Trainee> tq=em.createQuery(qry,Trainee.class);
		ArrayList<Trainee> list=(ArrayList<Trainee>)tq.getResultList();
		return list;

	}



}
