package com.cg.ma.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ma.bean.Assessmentbean;
import com.cg.ma.bean.TraineeBean;
import com.cg.ma.service.IService;
import com.cg.ma.service.Service;

/**
 * Servlet implementation class ModuleServlet
 */
@WebServlet("*.obj")
public class ModuleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		IService service =new Service();
		Assessmentbean abean=new Assessmentbean();
		TraineeBean tbean =new TraineeBean();
		
		
		String path=request.getServletPath().trim();
		String target="";
		
		switch(path)
		{
		case "/addassessment.obj" :
			try
			{
			List<TraineeBean> list= service.getid();
			request.setAttribute("list", list);
			  target="adddetails.jsp";
			}
			catch(Exception e)
			{
				request.setAttribute("error", e.getMessage());
				target="error.jsp";
			}
			  break;
		case "/module.obj" :
			
			try
			{
			int id=Integer.parseInt(request.getParameter("id"));
			String mname=request.getParameter("mname");
			int mpt=Integer.parseInt(request.getParameter("mpt"));
			int mtt=Integer.parseInt(request.getParameter("mtt"));
			int assign=Integer.parseInt(request.getParameter("assign"));
			//int gr = Integer.parseInt(request.getParameter("grade"));
			
			abean.setTraineeId(id);
			abean.setModuleName(mname);
			abean.setMpt(mpt);
			abean.setMtt(mtt);
			abean.setAssign(assign);
			//abean.setGrade(gr);
			
			
			int grade=0,add;
			
			add=(int) ((0.7*mpt)+(0.15*mtt)+(0.15*assign));
			if(add>=0 && add<=49)
				{
					grade=0;
				}
			else if(add>=50 && add<=59)
			{
				grade=1;
			}
			
			else if(add>=60 && add<=69)
			{
				grade=2;
			}
			
			else if(add>=70 && add<=79)
			{
				grade=3;
			}
			else if(add>=80 && add<=89)
			{
				grade=4;
			}
			else if(add>=90 && add<=100)
			{
				grade=5;
			}
			abean.setGrade(grade);
			abean=service.adddetails(abean);
			request.setAttribute("abean", abean);
			request.setAttribute("grade", grade);
			target="success.jsp";
		
			}
			catch(Exception e)
			{
				request.setAttribute("error", e.getMessage());
				target="error.jsp";
			}
		break;
		
		}
		
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doGet(request, response);
	}

}
