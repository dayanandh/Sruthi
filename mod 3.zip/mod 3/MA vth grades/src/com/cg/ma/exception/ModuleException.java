package com.cg.ma.exception;

public class ModuleException extends Exception {

	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public  ModuleException(String message)
	{
		
		super(message);
	}

}
