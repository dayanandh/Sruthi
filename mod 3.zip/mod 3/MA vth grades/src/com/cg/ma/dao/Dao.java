package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ma.bean.Assessmentbean;
import com.cg.ma.bean.TraineeBean;
import com.cg.ma.exception.ModuleException;
import com.cg.ma.util.DBConnection;

public class Dao implements Idao {

	@Override
	public Assessmentbean adddetails(Assessmentbean bean)
			throws ModuleException {
		
		
		try
		{
		Connection con=DBConnection.getConnection();
		PreparedStatement pstmt=con.prepareStatement(IQueryMapper.INSERT_QRY);
		pstmt.setInt(1, bean.getTraineeId());
		pstmt.setString(2,bean.getModuleName());
		pstmt.setInt(3, bean.getMpt());
		pstmt.setInt(4, bean.getMtt());
		pstmt.setInt(5, bean.getAssign());
		pstmt.setInt(6, bean.getGrade());
		int result=pstmt.executeUpdate();
		if(result<=0)
		{
			throw new ModuleException("Insertion Failed");
		}
		con.close();
		
		
		}
		catch(SQLException e)
		{
			throw new ModuleException("SQL Exception "+e.getMessage());
		}
		catch(Exception e)
		{
			throw new ModuleException("Exception "+e.getMessage());
		}
		return bean;
	}

	@Override
	public List<TraineeBean> getid() throws ModuleException {
		
		List<TraineeBean> list=new ArrayList<TraineeBean>();
		try
		{
		Connection con=DBConnection.getConnection();
		PreparedStatement pstmt=con.prepareStatement(IQueryMapper.SELECT_QRY);
		
		ResultSet rst=pstmt.executeQuery();
		while(rst.next())
		{
			TraineeBean tbean=new TraineeBean();
			tbean.setTraineeId(rst.getInt(1));
			
			list.add(tbean);
		}
		con.close();
		}
		catch(SQLException e)
		{
			throw new ModuleException("SQL Exception "+e.getMessage());
		}
		catch(Exception e)
		{
			throw new ModuleException("Exception "+e.getMessage());
		}
		return list;
	}

}
