package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.bean.Assessmentbean;
import com.cg.ma.bean.TraineeBean;
import com.cg.ma.exception.ModuleException;

public interface Idao {

	public Assessmentbean adddetails(Assessmentbean bean) throws ModuleException;
	public List<TraineeBean> getid() throws ModuleException;
	
}
