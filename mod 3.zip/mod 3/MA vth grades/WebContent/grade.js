/**
 * 
 */
function grade()
{
		var mpt=document.myform.mpt.value;
		var mtt=document.myform.mtt.value;
		var assign=document.myform.assign.value;
		var add;
	
		
		
		add=((0.7*mpt)+(0.15*mtt)+(0.15*assign));
		if(add>=0 && add<=49)
			{
				grade='0';
			}
		else if(add>=50 && add<=59)
		{
			grade='1';
		}
		
		else if(add>=60 && add<=69)
		{
			grade='2';
		}
		
		else if(add>=70 && add<=79)
		{
			grade='3';
		}
		else if(add>=80 && add<=89)
		{
			grade='4';
		}
		else if(add>=90 && add<=100)
		{
			grade='5';
		}
		alert("the grade is" + grade);
		return grade;
}