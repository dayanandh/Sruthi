package com.capgemini.ma.bean;

import java.time.LocalDate;

public class CustomerBean {

	private String cname;
	private String mailId;
	private String phoneNo;
	private int purchaseId;
	LocalDate purchaseDate;
	private String mobileId;
	
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getMobileId() {
		return mobileId;
	}
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "CustomerBean [cname=" + cname + ", mailId=" + mailId
				+ ", phoneNo=" + phoneNo + ", purchaseId=" + purchaseId
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
