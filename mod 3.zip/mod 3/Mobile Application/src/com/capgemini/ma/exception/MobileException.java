package com.capgemini.ma.exception;

public class MobileException extends Exception {

	
String message;
	
	public MobileException(String msg)
	{
		message=msg;
	}

	@Override
	public String getMessage()
	{
		return message;
	}
	
	
	
}
