package com.capgemini.ma.service;

import com.capgemini.ma.bean.CustomerBean;
import com.capgemini.ma.exception.MobileException;

public interface ICustomerService {
	
	public int addCustomerDetails(CustomerBean customer) throws MobileException;
	public CustomerBean getCustomerDetails(int purchaseID) throws MobileException;
 
}
