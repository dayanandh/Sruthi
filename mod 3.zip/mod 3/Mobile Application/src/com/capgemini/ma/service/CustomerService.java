package com.capgemini.ma.service;

import com.capgemini.ma.bean.CustomerBean;
import com.capgemini.ma.dao.CustomerDAO;
import com.capgemini.ma.dao.ICustomerDAO;
import com.capgemini.ma.exception.MobileException;



public class CustomerService  implements ICustomerService{


ICustomerDAO dao;
	
	public CustomerService() {
		// TODO Auto-generated constructor stub
		dao =new CustomerDAO();
	}
	

	public ICustomerDAO getDao() {
		return dao;
	}



	public void setDao(ICustomerDAO dao) {
		this.dao = dao;
	}
	
	
	static String namePattern = "[A-Z]{1}[a-z]{2,}";		//name format pattern
	static String emailPattern = "[A-Z a-z 0-9 . _ -]*@[a-z 0-9]*[.com .in .edu]*";
	static String contactPattern = "[0-9]{10}";				//mobile number format pattern
	static String mobileIdPattern = "[0-9]{4}";
 	
	@Override
	public int addCustomerDetails(CustomerBean customer)
		//	throws MobileException 
	{
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public CustomerBean getCustomerDetails(int purchaseID)
		//	throws MobileException 
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	//validating name 
	public static boolean validateName(String name)
	{
		boolean flag = false;
		if(name.matches(namePattern))
		{
			flag = true;
		}
		
		
		return flag;
	}
	//validating email
			public static boolean validateEmail(String email)
			{
				boolean flag = false;
				if(email.matches(emailPattern))
				{
					flag = true;
				}
				return flag;
			}
			//validating input phone number format
			public static boolean validateContact(String contact)
			{
				boolean flag = false;
				if(contact.matches(contactPattern))
				{
					flag = true;
				}
				return flag;
			}
	
	//validating mobile Id format
		public static boolean validatemobileId(String mobileId)
		{
			boolean flag = false;
			if(mobileId.matches(mobileIdPattern))
			{
				flag = true;
			}
			return flag;
		}
		
	
		
		
}
