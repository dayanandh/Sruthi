package com.capgemini.ma.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.ma.bean.CustomerBean;
import com.capgemini.ma.exception.MobileException;
import com.capgemini.ma.service.CustomerService;


public class Customer {

	public static void main(String[] args) {
		
		CustomerService service = new CustomerService();
		int choice ;
		String name,mobile,email,mobileId;
		boolean flag1,flag2,flag3,flag4;
		LocalDate purchaseDate = null;
		
		try(Scanner sc = new Scanner(System.in))
		{

			do											//do-while loop
			{
				System.out.println("\n************* Mobile Application *************");
				System.out.println("Choose an operation");
				System.out.println("1. Add Customer Information");
				System.out.println("2. Search customer by Purchase Id");
				System.out.println("3. Exit");
				System.out.println("******************************");
				System.out.print("\nPlease Enter a Choice : ");
				choice = sc.nextInt();
				System.out.println("\n******************************");
			
				
				switch(choice)
				{
				
				
					case 1 :// Add Customer Information
						{
							int purchaseId;
							//Customer Name
							do
							{
								System.out.println("Enter the name of the Customer");
								name=sc.next();
								flag1=service.validateName(name);
								if(flag1==false)
									System.out.println("Name should be entered in proper format(eg.Matt)");	
							}while(flag1==false);
							
							
							
							//Customer Email
							do
							{
								System.out.println("Enter Customer Email Id: ");
								email = sc.next();
								flag2=CustomerService.validateEmail(email);
								if(flag2==false)
									System.out.println("Email Id should be Valid");
							}while(flag2==false);

							//Customer Phone Number
							do
							{
								System.out.println("Enter Customer phone number : ");
								mobile = sc.next();
								flag3=CustomerService.validateContact(mobile);
								if(flag3==false)
									System.out.println("Phone number should be of 10 digits");
							}while(flag3==false);
							
							do
							{
								System.out.println("Enter Customer mobile ID : ");
								mobileId = sc.next();
								flag4=CustomerService.validatemobileId(mobileId);
								if(flag4==false)
									System.out.println("Enter Valid Mobile ID");
							}while(flag4==false);
							
							
							
							CustomerBean customer = new CustomerBean();
									
							customer.setCname(name);
							customer.setMailId(email);
							customer.setPhoneNo(mobile);
							customer.setPurchaseDate(purchaseDate);
							customer.setMobileId(mobileId);
							
							try
							{
								//calling addCustomerDetails method
								
								purchaseId=service.addCustomerDetails(customer);
								System.out.println("Succesfull");
								System.out.println("Customer Information stored succesfully for "
								+purchaseId);
								
							}
							catch(Exception e)
							{
								System.out.println(e.getMessage());
							
							}
							break;
						}
						
						
					case 2 ://search customer info through on purchase id
						{
							CustomerBean customer = new CustomerBean();
							System.out.print("\nEnter Purchase Id : ");
							int purchaseId = sc.nextInt();
							
							try 
							{
								//calling getCustomerDetails method
								customer = service.getCustomerDetails(purchaseId);
								System.out.println("----------------------------------------------------------");
								System.out.println("Purchase Id : "+customer.getPurchaseId());
								System.out.println("Name : "+customer.getCname());
								System.out.println("Email : "+customer.getMailId());
								System.out.println("Phone No : "+customer.getPhoneNo());
								System.out.println("Purchase Date :"+customer.getPurchaseDate());
								System.out.println("Mobile Id : "+customer.getMobileId());
								System.out.println("----------------------------------------------------------");
							}
							catch (Exception e) 
							{
							if(e.getMessage().contains("table")){
								System.out.println("technical issue with application ");
							}
							else
								System.out.println("There is no customer with this Purchase ID");
							}
						
							break;
						}
						
								
					}
					
					System.out.print("Do you want to continue? 1-Yes  0 - No : ");
					choice = sc.nextInt();
					
				}while(choice==1);
			
			}
			
		}
		
	}

