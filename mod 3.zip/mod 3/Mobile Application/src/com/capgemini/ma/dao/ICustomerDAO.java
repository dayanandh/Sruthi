package com.capgemini.ma.dao;



import com.capgemini.ma.bean.CustomerBean;
import com.capgemini.ma.exception.MobileException;

public interface ICustomerDAO {

	
	public int addCustomerDetails(CustomerBean customer) throws MobileException;
	public CustomerBean getCustomerDetails(int purchaseID) throws MobileException;
	
}
