package com.capgemini.ma.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;








import com.capgemini.ma.bean.CustomerBean;
import com.capgemini.ma.exception.MobileException;
import com.capgemini.ma.util.DBUtil;




public class CustomerDAO implements ICustomerDAO{

	Connection con = null;
//	static Logger log = DaoLogger.log; 		
	private CustomerBean purchaseId;
	
	public CustomerDAO() {
		// TODO Auto-generated constructor stub
		con = DBUtil.getConnect();					//Establishing connection
	}
	
	
	@Override
	public int addCustomerDetails(CustomerBean customer) throws MobileException  {
		// TODO Auto-generated method stub
		
		int purchaseId = 0;
		try
		{
			   purchaseId = getPurchaseId();		//Getting Unique Patient Id from Sequence
				String sql = "INSERT INTO purchasedetails VALUES(?, ?, ?, ?, ?, ?)";
				PreparedStatement pstmt = con.prepareStatement(sql);  //when many values to be passed
				
				pstmt.setInt(1, purchaseId);
				pstmt.setString(2, customer.getCname());
				pstmt.setString(3, customer.getMailId());
				pstmt.setString(4, customer.getPhoneNo());
				
				LocalDate today = LocalDate.now();
				Date sqlDate = Date.valueOf(today);
				pstmt.setDate(5, sqlDate);
				pstmt.setString(6, customer.getMobileId());
				
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
        /*
					//Logging the New Entry
					log.info("New Entry -> Patient ID : "+patientId
										+"\nName : "+patient.getPatient_name()
										+"\nAge : "+patient.getAge()
										+"\nPhone : "+patient.getPhone()
										+"\nDescription : "+patient.getDescription()
										+"\nConsultation Date : "+sqlDate);*/
				}
				else
				{
				//	log.error("System Error");
					throw new MobileException("System Error. Try Again Later.");
					
				}
		}
		catch(SQLException e) 
		{
			System.out.println((e.getMessage()));
		}		
		
		return purchaseId;
	}

	//Sequence to fetch next value of Purchase ID
		private int getPurchaseId() 
		{
			// TODO Auto-generated method stub
			int purchaseId = 0;
			String sql = "SELECT purchaseId_Seq.NEXTVAL FROM purchasedetails";
			try
			{
				PreparedStatement pstmt= con.prepareStatement(sql);
					ResultSet res = pstmt.executeQuery();
					if(res.next())
					{
						purchaseId = res.getInt(1);
					}
			}
			catch(SQLException e)
			{
				System.out.println((e.getMessage()));
			//	log.error(e.getMessage());
			}
			return purchaseId;		
			
		}
		

	@Override
	public CustomerBean getCustomerDetails(int purchaseID) throws MobileException {
		// TODO Auto-generated method stub
	/*	
		CustomerBean customer = new CustomerBean();
		if(validPurchaseId(purchaseID))			// Checking if purchase id Exists
		{
			try
			{
					String sql = "SELECT * FROM purchaseDetails WHERE purchaseId = ?";
					PreparedStatement pstmt = con.prepareStatement(sql);	
					pstmt. setInt(1, purchaseID);
					ResultSet res = pstmt.executeQuery();
					if(res.next())
					{
						customer.setPurchaseId(res.getInt(1));
						customer.setCname(res.getString(2));
						customer.setMailId(res.getString(3));
						customer.setPhoneNo(res.getString(4));	
						customer.setMobileId(res.getString(5));
						
						Date sqlDate = res.getDate(6);
						LocalDate date = sqlDate.toLocalDate();

						customer.setPurchaseDate(date);
					}
			}
						//Logging the Searched Entry
						log.info("New Entry -> Patient ID : "+patientId
											+"\nName : "+patient.getPatient_name()
											+"\nAge : "+patient.getAge()
											+"\nPhone : "+patient.getPhone()
											+"\nDescription : "+patient.getDescription()
											+"\nConsultation Date : "+sqlDate);
					}
					
			catch(SQLException e)
			{
				e.printStackTrace();
			//	log.error(e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		else
		{
		//	log.error("No Details available for Patient Id : "+patientId);
			throw new MobileException("\nSorry No Details Found.");
		}
		
	//	log.info(patient);
		return customer;
	}
	
	
	
	//Check if Patient Id exists in database
	private boolean validPurchaseId(int purchaseId)
	{
		// TODO Auto-generated method stub
		boolean flag = false;
		String query = "SELECT * FROM purchaseDetails WHERE purchaseId = ?";
		try
		{
			PreparedStatement pstmt = con.prepareStatement(query);	
			pstmt. setInt(1, purchaseId);
			ResultSet res = pstmt.executeQuery();
			if(res.next())
				flag = true;
		}
		catch(SQLException e)
		{
		//	log.error(e.getMessage());
		}          */
		return purchaseId;
	}


	

		
	
	

}
