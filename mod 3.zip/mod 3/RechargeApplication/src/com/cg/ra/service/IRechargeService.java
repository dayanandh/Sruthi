package com.cg.ra.service;

import java.util.List;

import com.cg.ra.bean.RechargeBean;
import com.cg.ra.bean.RechargeTableBean;
import com.cg.ra.exception.RechargeException;

public interface IRechargeService {
	public int addDetails(RechargeBean bean) throws RechargeException;
	public List<RechargeTableBean> fetchallDetails() throws RechargeException;
}
