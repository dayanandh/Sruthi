package com.cg.ra.service;

import java.util.List;

import com.cg.ra.bean.RechargeBean;
import com.cg.ra.bean.RechargeTableBean;
import com.cg.ra.dao.IRechargeDao;
import com.cg.ra.dao.RechargeDaoImpl;
import com.cg.ra.exception.RechargeException;

public class RechargeServiceImpl implements IRechargeService{

	IRechargeDao dao=new RechargeDaoImpl();
	
	@Override
	public int addDetails(RechargeBean bean) throws RechargeException {
		
		return dao.addDetails(bean);
	}

	@Override
	public List<RechargeTableBean> fetchallDetails() throws RechargeException {
		
		return dao.fetchallDetails();
	}

	

}
