package com.cg.ra.dao;

public class QueryMapper {
public static final String insert_query="insert into user_tbl values(user_id_seq.nextval,?,?,?)";
public static final String sequence_query="select user_id_seq.currval from dual";
public static final String fetchall_query="select planname,planamount from recharge_tbl";
}
