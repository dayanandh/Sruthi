package com.cg.ra.dao;

import java.util.List;

import com.cg.ra.bean.RechargeBean;
import com.cg.ra.bean.RechargeTableBean;
import com.cg.ra.exception.RechargeException;

public interface IRechargeDao {
public int addDetails(RechargeBean bean) throws RechargeException;
public List<RechargeTableBean> fetchallDetails() throws RechargeException;
}
