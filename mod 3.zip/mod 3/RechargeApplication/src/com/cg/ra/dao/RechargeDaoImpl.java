package com.cg.ra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;





import java.util.ArrayList;
import java.util.List;

import com.cg.ra.bean.RechargeBean;
import com.cg.ra.bean.RechargeTableBean;
import com.cg.ra.exception.RechargeException;
import com.cg.ra.util.DBConnection;

public class RechargeDaoImpl implements IRechargeDao{

	@Override
	public int addDetails(RechargeBean bean) throws RechargeException {
		int userId=0;
		try{
			Connection con=DBConnection.getConnection();
			PreparedStatement pst=con.prepareStatement(QueryMapper.insert_query);
			pst.setString(1, bean.getUserName());
			pst.setString(2, bean.getUserAddress());
			pst.setInt(3, bean.getcAmount());
			
			int result=pst.executeUpdate();
			if(result<=0)
			{
				throw new RechargeException("Failed to insert");
			}
			pst=con.prepareStatement(QueryMapper.sequence_query);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				userId=rst.getInt(1);
			}
			else
			{
				throw new RechargeException("Sequence not generated");
			}
			con.close();
			}
			catch(SQLException e)
			{
				throw new RechargeException("SQL Exception"+e.getMessage());
			}
			catch(Exception e)
			{
				throw new RechargeException(e.getMessage());
			}
			
		
		return userId;
	}

	@Override
	public List<RechargeTableBean> fetchallDetails() throws RechargeException {
		
		List<RechargeTableBean> list=new ArrayList<RechargeTableBean>();
		try{
		Connection con=DBConnection.getConnection();
		PreparedStatement pst=con.prepareStatement(QueryMapper.fetchall_query);
		ResultSet rst=pst.executeQuery();
		while(rst.next())
		{
			RechargeTableBean bean1=new RechargeTableBean();
			bean1.setPlanName(rst.getString("planname"));
			bean1.setPlanAmount(rst.getInt("planamount"));
			list.add(bean1);
		}
		con.close();
		}catch(SQLException e)
		{
			throw new RechargeException("SQL exception"+e.getMessage());
		}
		catch(Exception e)
		{
			throw new RechargeException(e.getMessage());
		}
		
		return list;
	}

}
