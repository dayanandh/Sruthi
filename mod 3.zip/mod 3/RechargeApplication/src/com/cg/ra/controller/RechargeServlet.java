package com.cg.ra.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.cg.ra.bean.RechargeBean;
import com.cg.ra.bean.RechargeTableBean;
import com.cg.ra.service.IRechargeService;
import com.cg.ra.service.RechargeServiceImpl;

/**
 * Servlet implementation class RechargeServlet
 */
@WebServlet("*.obj")
public class RechargeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		IRechargeService service= new RechargeServiceImpl();
		RechargeBean bean=new RechargeBean();
		List<RechargeTableBean> list=new ArrayList<RechargeTableBean>();
		RechargeTableBean bean1= new RechargeTableBean();
		String path=request.getServletPath().trim();
		String target="";
		
		switch(path)
		{
		case "/Home.obj":
			target = "index.jsp";
			break;

		case "/adding.obj":
			//out.println("u r in adding.obj");
			
			String uname = request.getParameter("uname").trim();
			String uaddress = request.getParameter("uaddress").trim();
			int camount = Integer.parseInt(request.getParameter("camount").trim());			
			
			
			try {
				bean.setUserName(uname);
				bean.setUserAddress(uaddress);
				bean.setcAmount(camount);

				int userId=service.addDetails(bean);
				
				bean.setUserId(userId);
				request.setAttribute("bean", bean);
				
				list=service.fetchallDetails();
				request.setAttribute("list", list);
				target="plan.jsp";

			} catch (Exception e) {
				request.setAttribute("error", e.getMessage());
				target = "error.jsp";
			}
			break;
			
		case "/calculate.obj":
			String pname = request.getParameter("pname").trim();
			int pamount = Integer.parseInt(request.getParameter("pamount").trim());
			int cam = Integer.parseInt(request.getParameter("cam").trim());
			if(pamount>cam)
			{
				int difference=pamount-cam;
				request.setAttribute("difference", difference);
				target="fail.jsp";
			}
			if(pamount<cam)
			{
				int difference=cam-pamount;
				request.setAttribute("difference", difference);
				target="success.jsp";
			}
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
