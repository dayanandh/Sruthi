package com.cg.pms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.service.IProductService;
import com.cg.pms.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("*.obj")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		IProductService service=new ProductServiceImpl();
		ProductBean bean=new ProductBean();
		String path=request.getServletPath().trim();
		String target="";
		switch(path){
		
		case "/home.obj":out.println();
						target="index.jsp";
						break;
		case "/addproduct.obj":
						target="addingproduct.jsp";
						break;
		case "/addingproduct.obj":
			try{		String pname=request.getParameter("pname");
						int pprice=Integer.parseInt(request.getParameter("pprice"));
						int pqty=Integer.parseInt(request.getParameter("pqty"));
						bean.setProductName(pname);
						bean.setProductPrice(pprice);
						bean.setProductQty(pqty);
						int pid=service.addProduct(bean);
						request.setAttribute("pname", pname);
						request.setAttribute("pprice",pprice );
						request.setAttribute("pid",pid );
						request.setAttribute("pqty",pqty);
						target="successadded.jsp";
				}catch(Exception e){
					request.setAttribute("error",e.getMessage());
					target="error.jsp";
				}
						break;
		case "/searchbyid.obj":
						target="searchbyid.jsp";
						break;
		case "/aftersearch.obj":
						try{int pid=Integer.parseInt(request.getParameter("pid"));
						bean=service.searchProduct(pid);
						request.setAttribute("bean", bean);
						target="found.jsp";
						}catch(Exception e){
							request.setAttribute("error",e.getMessage());
							target="error.jsp";
						}
						break;
		
		case "/viewall.obj" :try{
							 List<ProductBean> list=service.viewAllProducts();
							 request.setAttribute("list", list);
							 target="viewallproduct.jsp";
								}
							catch(Exception e){
								request.setAttribute("error",e.getMessage());
								target="error.jsp";
							}
							 break;
							 
									 
		case "/showproduct.obj": request.setAttribute("pId",request.getParameter("pId"));
								 request.setAttribute("pname",request.getParameter("pname"));
								 request.setAttribute("pprice",request.getParameter("pprice"));
								 request.setAttribute("pqty",request.getParameter("pqty"));
			
								target="showproduct.jsp";
								break;
		case "/update.obj":		try{int pid=Integer.parseInt(request.getParameter("pid"));
								int pqty=Integer.parseInt(request.getParameter("pqty"));
								int userqty=Integer.parseInt(request.getParameter("userqty"));
								int qty=pqty-userqty;
								service.updateProduct(pid, qty);
								target="updated.jsp";
								}
								catch(Exception e){
								request.setAttribute("error",e.getMessage());
								target="error.jsp";
								}
		 						break;
		 
								
		case "/deleteproduct.obj":
							    try{
							    	int pId=Integer.parseInt(request.getParameter("pId"));
							    
							    bean=service.deleteProduct(pId);
							    request.setAttribute("bean", bean);
								target="deletedproduct.jsp";
							    }
							    catch(Exception e){
									request.setAttribute("error",e.getMessage());
									target="error.jsp";
									}
								break;
		
		
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
