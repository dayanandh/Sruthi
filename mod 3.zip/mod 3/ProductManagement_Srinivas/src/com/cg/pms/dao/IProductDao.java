package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.exception.ProductException;

public interface IProductDao {

	public int addProduct(ProductBean bean) throws ProductException;
	public ProductBean searchProduct(int productId) throws ProductException;
	public List<ProductBean> viewAllProducts() throws ProductException;
	public boolean updateProduct(int productId,int qty) throws ProductException;
	public ProductBean deleteProduct(int productId)throws ProductException;
	
	
	
	
}
