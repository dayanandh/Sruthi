package com.cg.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.exception.ProductException;
import com.cg.pms.util.DBConnection;

public class ProductDaoImpl implements IProductDao {

	@Override
	public int addProduct(ProductBean bean) throws ProductException {
		int productId = 0;
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.INSERT_QRY);
			pstmt.setString(1, bean.getProductName());
			pstmt.setInt(2, bean.getProductPrice());
			pstmt.setInt(3, bean.getProductQty());
			int result = pstmt.executeUpdate();
			if (result <= 0) {
				throw new ProductException("Fail To Insert");
			}
				pstmt = con.prepareStatement(QueryMapper.SEQ_QRY);
				ResultSet rst = pstmt.executeQuery();
				if (rst.next()) {
					productId = rst.getInt(1);

				} else {
					throw new ProductException("Sequence is not Created");
				}

			con.close();
		} catch (SQLException e) {
			throw new ProductException("SQL EXCEPTION" + e.getMessage());
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		

		return productId;
	}

	@Override
	public ProductBean searchProduct(int productId) throws ProductException {
		ProductBean bean = new ProductBean();
		try{
			Connection con = DBConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.SEARCH_ARY);
		pstmt.setInt(1, productId);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next())
		{
			bean.setProductId(rst.getInt("productid"));
			bean.setProductName(rst.getString("productname"));
			bean.setProductPrice(rst.getInt("productprice"));
			bean.setProductQty(rst.getInt("productqty"));
			
		}
		else{
			throw new ProductException("Product Not Found");
		}
		con.close();
		}
		catch (SQLException e) {
			throw new ProductException("SQL EXCEPTION" + e.getMessage());
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}

		return bean;
	}

	@Override
	public List<ProductBean> viewAllProducts() throws ProductException {
		List<ProductBean> list = new ArrayList<ProductBean>();
		try{
			
	
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.VIEWALL_QRY);
		ResultSet rst=pstmt.executeQuery();
		while(rst.next()){
			ProductBean bean = new ProductBean();
			bean.setProductId(rst.getInt("productid"));
			bean.setProductName(rst.getString("productname"));
			bean.setProductPrice(rst.getInt("productprice"));
			bean.setProductQty(rst.getInt("productqty"));
			list.add(bean);
		}
		con.close();
		}
		catch (SQLException e) {
			throw new ProductException("SQL EXCEPTION" + e.getMessage());
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}

		
		
		return list;
	}

	@Override
	public boolean updateProduct(int productId, int qty)
			throws ProductException {
		boolean flag=false;
		try{
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.UPDATE_QRY);
		pstmt.setInt(1, qty);
		pstmt.setInt(2, productId);
		int rst=pstmt.executeUpdate();
		if(rst<=0){
			flag=true;
		}
		else{
			flag=false;
		}
		con.close();
		}
		catch (SQLException e) {
			throw new ProductException("SQL EXCEPTION" + e.getMessage());
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		
		
		return flag;
	}

	@Override
	public ProductBean deleteProduct(int productId) throws ProductException {
		ProductBean bean=new ProductBean();
		try{
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.SEARCH_ARY);
		pstmt.setInt(1, productId);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next())
		{
			bean.setProductId(rst.getInt("productid"));
			bean.setProductName(rst.getString("productname"));
			bean.setProductPrice(rst.getInt("productprice"));
			bean.setProductQty(rst.getInt("productqty"));
			
		}
		else{
			throw new ProductException("Product Not Found");
		}
		PreparedStatement stmt = con.prepareStatement(QueryMapper.DELETE_QRY);
		stmt.setInt(1, productId);
		stmt.executeUpdate();

		con.close();
		}
		catch (SQLException e) {
			throw new ProductException("SQL EXCEPTION" + e.getMessage());
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}


		return bean ;
	}

}
