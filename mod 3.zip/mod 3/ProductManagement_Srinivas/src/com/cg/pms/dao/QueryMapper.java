package com.cg.pms.dao;

public interface QueryMapper {
public static final String INSERT_QRY="INSERT INTO product_tbl VALUES(product_seq.nextval,?,?,?)";
public static final String SEARCH_ARY="SELECT productid,productname,productprice,productqty from product_tbl where productid=?";
public static final String VIEWALL_QRY="SELECT productid,productname,productprice,productqty from product_tbl ";
public static final String SEQ_QRY="select product_seq.currval from dual";
public static final String UPDATE_QRY="update product_tbl set productqty=? where productid=?";
public static final String DELETE_QRY="delete from product_tbl where productid=?";
}
