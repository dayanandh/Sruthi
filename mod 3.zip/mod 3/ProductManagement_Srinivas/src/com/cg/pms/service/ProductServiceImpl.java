package com.cg.pms.service;

import java.util.List;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.dao.IProductDao;
import com.cg.pms.dao.ProductDaoImpl;
import com.cg.pms.exception.ProductException;

public class ProductServiceImpl implements IProductService {
private IProductDao dao=new ProductDaoImpl(); 
	@Override
	public int addProduct(ProductBean bean) throws ProductException {
		
		return dao.addProduct(bean);
	}

	@Override
	public ProductBean searchProduct(int productId) throws ProductException {
		
		return dao.searchProduct(productId);
	}

	@Override
	public List<ProductBean> viewAllProducts() throws ProductException {
		
		return dao.viewAllProducts();
	}

	@Override
	public boolean updateProduct(int productId, int qty)
			throws ProductException {
		// TODO Auto-generated method stub
		return dao.updateProduct(productId, qty);
	}

	@Override
	public ProductBean deleteProduct(int productId) throws ProductException {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productId);
	}

}
