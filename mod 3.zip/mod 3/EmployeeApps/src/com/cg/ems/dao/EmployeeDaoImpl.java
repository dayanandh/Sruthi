package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;


import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao{

	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int empid = 0;
		Connection con = null;
		
		try
		{
		con = DBConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.INSERT_QRY);
		
		pstmt.setString(1, bean.getEmployeeName());
		pstmt.setInt(2,bean.getEmployeeSalary());
		
		int result = pstmt.executeUpdate();
		if(result > 0)
		{
			pstmt = con.prepareStatement(QueryMapper.SEQ_QRY);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
			{
				empid = rst.getInt(1);
			}
			else
			{
				throw new EmployeeException("SEQUENCY NOT FOUND");
			}
		}
		else
		{
			throw new EmployeeException("INSERT FAILED");
		}
		}catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return empid;
	}

	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		try
		{
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.VIEWALL_QRY);
		ResultSet rst = pstmt.executeQuery();
		while(rst.next())
		{
			EmployeeBean bean= new EmployeeBean();
			bean.setEmployeeId(rst.getInt("empid"));
			bean.setEmployeeName(rst.getString("empname"));
			bean.setEmployeeSalary(rst.getInt("empsal"));
			list.add(bean);
		}
		con.close();
		}catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return list;
	}

	
}
