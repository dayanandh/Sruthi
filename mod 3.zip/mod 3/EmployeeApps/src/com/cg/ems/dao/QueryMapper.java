package com.cg.ems.dao;

public interface QueryMapper {

	public static final String INSERT_QRY="insert into employee_tbl values(employee_seq.nextval,?,?)";
	public static final String SEQ_QRY="select employee_seq.currval from dual";
	public static final String VIEWALL_QRY ="select empid,empname,empsal from employee_tbl";
}
