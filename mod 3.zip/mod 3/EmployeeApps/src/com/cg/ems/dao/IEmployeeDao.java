package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeDao {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException;
}
