package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService
{

	private IEmployeeDao dao = new EmployeeDaoImpl();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int empid = dao.addEmployee(bean);
		return empid;
	}
	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.viewAllEmployees();
	}

}
