package com.cg.gamecity.bean;

public class GameBean {
	
	private String gameName;
	private int gameCost;
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public int getGameCost() {
		return gameCost;
	}
	public void setGameCost(int gameCost) {
		this.gameCost = gameCost;
	}
	

}
