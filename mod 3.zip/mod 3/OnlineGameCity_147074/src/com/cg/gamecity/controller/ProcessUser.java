package com.cg.gamecity.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.gamecity.bean.GameBean;
import com.cg.gamecity.bean.UserBean;
import com.cg.gamecity.dao.GameDaoImpl;
import com.cg.gamecity.dao.IGameDao;


/**
 * Servlet implementation class ProcessUser
 */
@WebServlet("*.obj")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(true);
		IGameDao service = new GameDaoImpl();
		
		String path=request.getServletPath().trim();
		List<GameBean> list=new ArrayList<GameBean>();
        GameBean bean1= new GameBean();
		
		String target="";
		
		switch(path)
		{

		case "/adding.obj" :
			
								try
								{
								
								UserBean bean=new UserBean();
								String name=request.getParameter("name");
								
								String address = request.getParameter("address");
								int amount=Integer.parseInt(request.getParameter("amount"));
								bean.setUserName(name);
								bean.setAddress(address);
								bean.setAmount(amount);
								int userid=service.addUser(bean);
								
								bean.setUserId(userid);
								request.setAttribute("bean",bean);
								list=service.getGameDetails();
								request.setAttribute("list", list);
								
								target="Play.jsp";
								}catch(Exception e)
								{
								
									request.setAttribute("error", e.getMessage());
			                    	target="error.jsp";
								}
								break;
		case "/calculate.obj" :
			String gname = request.getParameter("name").trim();
            int gamount = Integer.parseInt(request.getParameter("gamount").trim());
            int amount = Integer.parseInt(request.getParameter("camount").trim());
            int camount=amount-100;
            if(gamount>camount)
            {
                int difference=gamount-camount;
                session.setAttribute("difference", difference);
                session.setAttribute("gname", gname);
                target="Topup.jsp";
            }
            if(gamount<=camount)
            {
                int difference=camount-gamount;
                session.setAttribute("difference", difference);
                session.setAttribute("gname", gname);
                target="Success.jsp";
            }
            break;
								
								
		
		
		
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request,response);
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}
}
