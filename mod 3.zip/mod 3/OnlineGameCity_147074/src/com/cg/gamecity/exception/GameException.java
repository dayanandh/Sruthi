package com.cg.gamecity.exception;

public class GameException extends Exception {
	
	public GameException(String message)
	{
		super(message);
	}

}
