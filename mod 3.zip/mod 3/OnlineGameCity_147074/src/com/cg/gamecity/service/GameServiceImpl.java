package com.cg.gamecity.service;

import java.util.List;

import com.cg.gamecity.bean.GameBean;
import com.cg.gamecity.bean.UserBean;
import com.cg.gamecity.dao.GameDaoImpl;
import com.cg.gamecity.dao.IGameDao;
import com.cg.gamecity.exception.GameException;

public class GameServiceImpl implements IGameService{
	
	IGameDao dao= new GameDaoImpl(); 

	@Override
	public int addUser(UserBean bean) throws GameException {
		// TODO Auto-generated method stub
		return dao.addUser(bean);
	}

	@Override
	public List<GameBean> getGameDetails() throws GameException {
		// TODO Auto-generated method stub
		return dao.getGameDetails();
	}

}
