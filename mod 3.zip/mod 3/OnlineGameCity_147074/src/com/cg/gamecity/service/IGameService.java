package com.cg.gamecity.service;

import java.util.List;

import com.cg.gamecity.bean.GameBean;
import com.cg.gamecity.bean.UserBean;
import com.cg.gamecity.exception.GameException;

public interface IGameService {
	public int addUser(UserBean bean) throws GameException;
	public List<GameBean> getGameDetails()throws GameException;

}
