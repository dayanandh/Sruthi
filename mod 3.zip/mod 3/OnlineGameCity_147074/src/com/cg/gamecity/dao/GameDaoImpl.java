package com.cg.gamecity.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.gamecity.bean.GameBean;
import com.cg.gamecity.bean.UserBean;
import com.cg.gamecity.exception.GameException;
import com.cg.gamecity.util.DbConnection;


public class GameDaoImpl implements IGameDao{
	
	

	@Override
	public int addUser(UserBean bean) throws GameException {
		
		
		int userId=0;
		try
		{
		Connection con = DbConnection.getConnection();
		PreparedStatement pstmt=con.prepareStatement(IQueryMapper.INSERT_QRY);
		pstmt.setString(1,bean.getUserName());
		pstmt.setString(2, bean.getAddress());
		pstmt.setInt(3, bean.getAmount());
		
		int result = pstmt.executeUpdate();
		if(result<=0)
		{
			throw new GameException("Failed to Insert");
		}
		pstmt=con.prepareStatement(IQueryMapper.SEQ_QRY);
		ResultSet rst = pstmt.executeQuery();
		if(rst.next())
		{
			userId=rst.getInt(1);
		}
		else
		{
			throw new GameException("SEQUENCE FAILED");
		}
		con.close();
		}catch(SQLException e)
		{
			throw new GameException("SQL Exception" + e.getMessage());
		}
		catch(Exception e)
		{
			throw new GameException(e.getMessage());
		}
	
		return userId;

	}

	@Override
	public List<GameBean> getGameDetails() throws GameException {
		// TODO Auto-generated method stub
List<GameBean> list=new ArrayList<GameBean>();
		
		try
		{
		Connection con=DbConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(IQueryMapper.VIEWALL_QRY);
		ResultSet rst = pstmt.executeQuery();
		while(rst.next())
		{
			GameBean bean = new GameBean();
			bean.setGameName(rst.getString("name"));
			bean.setGameCost(rst.getInt("amount"));
			
			list.add(bean);
		}
		con.close();
		}catch(SQLException e)
		{
			throw new GameException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new GameException(e.getMessage());
		}
		
		return list;
	}

}
