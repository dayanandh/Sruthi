package com.cg.gamecity.dao;

public interface IQueryMapper {
	
	public static final String INSERT_QRY   = " insert into users values (seq_users.nextval,?,?,?)";
	public static final String SEQ_QRY   = " select seq_users.nextval from dual";
	public static final String VIEWALL_QRY   = " select name,amount from onlinegames";
	

}
