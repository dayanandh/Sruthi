package com.cg.rt.exception;

public class RegistrationException extends Exception{
	public RegistrationException(String message){
		super(message);
	}
}
