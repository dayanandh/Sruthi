package com.cg.rt.bean;

public class RegBean {
private String fName;
private String lName;
private String pass;
private String Gender;
private String skill;
private String city;
public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getGender() {
	return Gender;
}
public void setGender(String gender) {
	Gender = gender;
}
public String getSkill() {
	return skill;
}
public void setSkill(String skill) {
	this.skill = skill;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
@Override
public String toString() {
	return "	<h3 align='center' align-text='left'><br>Your Details: \n <br> First Name :		" + fName + "<br>\n Last Name:		" + lName + "<br>\n password		: *********"
			+ "<br>\n Gender		:" + Gender + "<br>\n Skill Set:		" + skill + "<br> \n City		: " + city+"</h3>";
}

}
