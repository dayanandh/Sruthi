package com.cg.rt.service;

import com.cg.rt.Dao.IRegisterDao;
import com.cg.rt.Dao.RegisterDaoImpl;
import com.cg.rt.bean.RegBean;
import com.cg.rt.exception.RegistrationException;

public class RegisterServiceImpl implements IRegisterService
{
 IRegisterDao dao=new RegisterDaoImpl();
	@Override
	public RegBean addDetails(RegBean reg) throws RegistrationException {
		// TODO Auto-generated method stub
		return dao.addDetails(reg);
	}

}
