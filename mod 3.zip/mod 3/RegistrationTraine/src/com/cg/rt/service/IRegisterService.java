package com.cg.rt.service;

import com.cg.rt.bean.RegBean;
import com.cg.rt.exception.RegistrationException;

public interface IRegisterService {
	public RegBean addDetails(RegBean reg) throws RegistrationException;
	
}