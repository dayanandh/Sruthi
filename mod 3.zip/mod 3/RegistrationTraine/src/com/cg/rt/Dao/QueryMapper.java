package com.cg.rt.Dao;

public interface QueryMapper {
public static final String INSERt_QRY="insert into RegisteredUsers values(?,?,?,?,?,?)";

}
