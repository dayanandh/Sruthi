package com.cg.rt.Dao;

import com.cg.rt.bean.RegBean;
import com.cg.rt.exception.RegistrationException;

public interface IRegisterDao {
public RegBean addDetails(RegBean reg) throws RegistrationException;
}
