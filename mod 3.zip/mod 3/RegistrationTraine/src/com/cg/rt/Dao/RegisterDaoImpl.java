package com.cg.rt.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import com.cg.rt.bean.RegBean;
import com.cg.rt.exception.RegistrationException;
import com.cg.rt.util.DBConnection;

public class RegisterDaoImpl implements IRegisterDao{

	@Override
	public RegBean addDetails(RegBean reg) throws RegistrationException {
		
		try{
	Connection	 con=null;
	con=DBConnection.getConnection();
		PreparedStatement pstmt=con.prepareStatement(QueryMapper.INSERt_QRY);
		pstmt.setString(1,reg.getfName());
		pstmt.setString(2, reg.getlName());
		pstmt.setString(3,reg.getPass());
		pstmt.setString(4, reg.getGender());
		pstmt.setString(5,reg.getSkill());
		pstmt.setString(6, reg.getCity());
		int result= pstmt.executeUpdate();
		if(result>0){
			

		}
		else{
			throw new RegistrationException("Insert Failed!!!");
		}
		}
		catch(Exception e){
			throw new RegistrationException(e.getMessage());
		}
		return reg;

	}

}
