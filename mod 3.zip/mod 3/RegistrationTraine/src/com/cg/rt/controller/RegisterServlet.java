package com.cg.rt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.rt.bean.RegBean;
import com.cg.rt.service.IRegisterService;
import com.cg.rt.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		IRegisterService service = new RegisterServiceImpl();
		String fName=request.getParameter("t1");
		String lName=request.getParameter("t2");
		String pass=request.getParameter("t3");
		String gender=request.getParameter("t4");
		String[] skill=request.getParameterValues("t5");
		String Skillset="";
		for(int i=0;i<skill.length;i++){
			Skillset=Skillset.concat(skill[i]+" ,");
			
		}
		
		
		String city=request.getParameter("t6");
		RegBean reg=new RegBean();
		reg.setfName(fName);
		reg.setlName(lName);
		reg.setPass(pass);
		reg.setGender(gender);
		reg.setSkill(Skillset);
		reg.setCity(city);
		RegBean rer=new RegBean();
		String message = null;
		try{
			
			rer=service.addDetails(reg);
			
			message="Details Successfully added!!! \n"+rer;
		}catch(Exception e){
			message=e.getMessage();
		}
		request.setAttribute("message", message);
		RequestDispatcher rd= request.getRequestDispatcher("DisplayServlet");
			rd.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
