package com.cg.eb.service;

import java.util.List;

import com.cg.eb.bean.BillBean;
import com.cg.eb.exception.EBillException;

public interface IBillService {
	public int addBillDetails(BillBean bean) throws EBillException; 
	public BillBean searchById(int billId) throws EBillException;
	public List<BillBean> viewAllBills() throws EBillException;
	public List<Integer> idre() throws EBillException;
	public String nameFetch(int cno) throws EBillException;
}
