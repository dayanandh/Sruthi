package com.cg.eb.service;

import java.util.List;

import com.cg.eb.bean.BillBean;
import com.cg.eb.dao.BillDaoImpl;
import com.cg.eb.dao.IBillDao;
import com.cg.eb.exception.EBillException;

public class BillServiceImpl implements IBillService{
private IBillDao dao=new BillDaoImpl();
	@Override
	public int addBillDetails(BillBean bean) throws EBillException {
		
		return dao.addBillDetails(bean);
	}

	@Override
	public BillBean searchById(int billId) throws EBillException {
		
		return dao.searchById(billId);
	}

	@Override
	public List<BillBean> viewAllBills() throws EBillException {
		
		return dao.viewAllBills();
	}

	@Override
	public List<Integer> idre() throws EBillException {
		// TODO Auto-generated method stub
		return dao.idre();
	}

	@Override
	public String nameFetch(int cno) throws EBillException {
	
		return dao.nameFetch(cno);
	}

}
