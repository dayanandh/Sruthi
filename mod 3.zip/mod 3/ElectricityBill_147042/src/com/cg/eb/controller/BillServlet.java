package com.cg.eb.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.eb.bean.BillBean;
import com.cg.eb.service.BillServiceImpl;
import com.cg.eb.service.IBillService;


/**
 * Servlet implementation class BillServlet
 */
@WebServlet("*.obj")
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillServlet() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		IBillService service=new BillServiceImpl();
		BillBean bean =new BillBean();
		String path=request.getServletPath().trim();
		String target="";
		switch(path){
		
		case "/home.obj":
						target="index.jsp";
						break;
		case "/view.obj":
			
						try{
							List<BillBean> list=service.viewAllBills();
							request.setAttribute("list", list);
							target="view.jsp";
							}
						catch(Exception e){
							request.setAttribute("error",e.getMessage());
							target="error.jsp";
							}
						break;
						
						
						
		case "/search.obj":
						target="searchid.jsp";
						break;
		case "/searching.obj":
					
			
			
						try{
							int bid=Integer.parseInt(request.getParameter("bid"));
							bean=service.searchById(bid);
							request.setAttribute("bean", bean);
							target="aftersearch.jsp";
							}
						catch(Exception e){
							request.setAttribute("error",e.getMessage());
							target="error.jsp";
							}
						
						break;
						
						
						
		case "/add.obj":
			try{
			List<Integer> list=service.idre();
			request.setAttribute("list", list);
						target="add.jsp";
			}catch(Exception e){
				request.setAttribute("error",e.getMessage());
				target="error.jsp";
			}
						break;
		case "/adding.obj":
			try{
				
			int FC=100; 
			int  consumerNo=Integer.parseInt(request.getParameter("cid"));
			double lastRead =Double.parseDouble((request.getParameter("lread")));
			double currRead =Double.parseDouble(request.getParameter("cread"));
			double units=currRead-lastRead;
			double netAmt=1.15*units+FC;
			LocalDate date=LocalDate.now();
			bean.setConsumerNo(consumerNo);
			bean.setCurrRead(currRead);
			bean.setUnitsConsumed(units);
			bean.setNetAmt(netAmt);
			bean.setBillDate(date);
		
			int bid=service.addBillDetails(bean);
			bean.setBillNo(bid);
			request.setAttribute("bean", bean);
			String name=service.nameFetch(consumerNo);
			request.setAttribute("name", name);
			target="added.jsp";
	}catch(Exception e){
		request.setAttribute("error",e.getMessage());
		target="error.jsp";
	}
						
						break;
					}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
