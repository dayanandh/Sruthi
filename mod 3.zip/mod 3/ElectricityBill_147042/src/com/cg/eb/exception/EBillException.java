package com.cg.eb.exception;

public class EBillException extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public EBillException(String message)
	{
	super(message);
	}
}
