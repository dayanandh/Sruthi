package com.cg.eb.dao;

public interface QueryMapper {
public 	static final String INSERT_QRY="insert into billdetails values(seq_bill_num.nextval,?,?,?,?,?)";
public 	static final String SEARCH_QRY="select bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date from billdetails where bill_num=?";
public 	static final String VIEWALL_QRY="select bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date from billdetails";
public 	static final String SEQ_QRY="select seq_bill_num.currval from dual";
public  static final String Id_QRY="select consumer_num from consumers"; 
public  static final String Name_QRY="select consumer_name from consumers where consumer_num=?";
}
