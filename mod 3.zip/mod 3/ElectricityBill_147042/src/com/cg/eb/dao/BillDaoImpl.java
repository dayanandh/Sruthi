package com.cg.eb.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.eb.bean.BillBean;
import com.cg.eb.exception.EBillException;
import com.cg.eb.util.DBConnection;




public class BillDaoImpl implements IBillDao {

	@Override
	public int addBillDetails(BillBean bean) throws EBillException {
	int billId=0;
	try {
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.INSERT_QRY);
		pstmt.setInt(1, bean.getConsumerNo());
		pstmt.setDouble(2, bean.getCurrRead());
		pstmt.setDouble(3, bean.getUnitsConsumed());
		pstmt.setDouble(4, bean.getNetAmt());
		LocalDate today = LocalDate.now();
		Date sqlDate = Date.valueOf(today);		
		pstmt.setDate(5, sqlDate);
		
		int result = pstmt.executeUpdate();
		if (result <= 0) {
			throw new EBillException("Fail To Insert");
		}
			pstmt = con.prepareStatement(QueryMapper.SEQ_QRY);
			ResultSet rst = pstmt.executeQuery();
			if (rst.next()) {
				billId = rst.getInt(1);

			} else {
				throw new EBillException("Sequence is not Created");
			}

		con.close();
	} catch (SQLException e) {
		throw new EBillException("SQL EXCEPTION" + e.getMessage());
	} catch (Exception e) {
		throw new EBillException(e.getMessage());
	}
	
	
		return billId;
	}

	@Override
	public BillBean searchById(int billId) throws EBillException {
		BillBean bean=new BillBean();
		try{
			Connection con = DBConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.SEARCH_QRY);
		pstmt.setInt(1, billId);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next())
		{
			bean.setBillNo(rst.getInt("bill_num"));
			bean.setConsumerNo(rst.getInt("consumer_num"));
			bean.setCurrRead(rst.getDouble("cur_reading"));
			bean.setUnitsConsumed(rst.getDouble("unitConsumed"));
			bean.setNetAmt(rst.getDouble("netAmount"));
			Date sqlDate = rst.getDate("bill_date");
			LocalDate date = sqlDate.toLocalDate();
			bean.setBillDate(date);
			
		}
		else{
			throw new EBillException("Product Not Found");
		}
		con.close();
		}
		catch (SQLException e) {
			throw new EBillException("SQL EXCEPTION" + e.getMessage());
		} catch (Exception e) {
			throw new EBillException(e.getMessage());
		}
		
		
		return bean;
	}

	@Override
	public List<BillBean> viewAllBills() throws EBillException {
		List<BillBean> list=new ArrayList<BillBean>();
		try{
			
			
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.VIEWALL_QRY);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next()){
				BillBean bean = new BillBean();
				bean.setBillNo(rst.getInt("bill_num"));
				bean.setConsumerNo(rst.getInt("consumer_num"));
				bean.setCurrRead(rst.getDouble("cur_reading"));
				bean.setUnitsConsumed(rst.getDouble("unitConsumed"));
				bean.setNetAmt(rst.getDouble("netAmount"));
				Date sqlDate = rst.getDate("bill_date");
				LocalDate date = sqlDate.toLocalDate();
				bean.setBillDate(date);
				list.add(bean);
			}
			con.close();
			}
			catch (SQLException e) {
				throw new EBillException("SQL EXCEPTION" + e.getMessage());
			} catch (Exception e) {
				throw new EBillException(e.getMessage());
			}

			
		
		return list;
	}

	@Override
	public List<Integer> idre() throws EBillException {
		List<Integer> list=new ArrayList<Integer>();
		int Id;
		try{
			
			
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.Id_QRY);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next()){
				
				Id=rst.getInt("consumer_num");
				
				list.add(Id);
			}
			con.close();
			}
			catch (SQLException e) {
				throw new EBillException("SQL EXCEPTION" + e.getMessage());
			} catch (Exception e) {
				throw new EBillException(e.getMessage());
			}

			
		
		return list;
	}

	@Override
	public String nameFetch(int cno) throws EBillException {
		String name="";
		try{
			Connection con = DBConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(QueryMapper.Name_QRY);
		pstmt.setInt(1,cno);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next())
		{
			name=(rst.getString(1));
			
			
		}
		else{
			throw new EBillException("Name Not Found");
		}
		con.close();
		}
		catch (SQLException e) {
			throw new EBillException("SQL EXCEPTION" +"Hai am here"+ e.getMessage());
		} catch (Exception e) {
			throw new EBillException(e.getMessage());
		}
		
		
		return name;
	}

}
