package com.cg.eb.bean;

public class ConsumerBean {
private int consumerNo;
private String consumerName;
private String consumerAddress;
public int getConsumerNo() {
	return consumerNo;
}
public void setConsumerNo(int consumerNo) {
	this.consumerNo = consumerNo;
}
public String getConsumerName() {
	return consumerName;
}
public void setConsumerName(String consumerName) {
	this.consumerName = consumerName;
}
public String getConsumerAddress() {
	return consumerAddress;
}
public void setConsumerAddress(String consumerAddress) {
	this.consumerAddress = consumerAddress;
}

}
