package com.cg.eb.bean;

import java.time.LocalDate;

public class BillBean {
private int billNo;
private int consumerNo;
private double currRead;
private double unitsConsumed;
private double netAmt;
private LocalDate billDate;
public int getBillNo() {
	return billNo;
}
public void setBillNo(int billNo) {
	this.billNo = billNo;
}
public int getConsumerNo() {
	return consumerNo;
}
public void setConsumerNo(int consumerNo) {
	this.consumerNo = consumerNo;
}
public double getCurrRead() {
	return currRead;
}
public void setCurrRead(double currRead) {
	this.currRead = currRead;
}
public double getUnitsConsumed() {
	return unitsConsumed;
}
public void setUnitsConsumed(double unitsConsumed) {
	this.unitsConsumed = unitsConsumed;
}
public double getNetAmt() {
	return netAmt;
}
public void setNetAmt(double netAmt) {
	this.netAmt = netAmt;
}
public LocalDate getBillDate() {
	return billDate;
}
public void setBillDate(LocalDate billDate) {
	this.billDate = billDate;
}


}
