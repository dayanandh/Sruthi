
public class Example1 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int num=Integer.parseInt(args[0]);
		 boolean flag= true;
		 for(int i=1;i<Math.sqrt(num) ;i++)
		 {
			 if(num%i==0)
			 {
				 flag=false;
				 break;
			 }
		 }
			 if(count == 2){
				 System.out.println(+num+ "prime number");
			 }
			 else{
				 System.out.println(+num+ "composite number");
			 }
		 
	}

}
