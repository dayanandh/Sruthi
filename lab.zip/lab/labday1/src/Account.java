
public class Account {
	
	private int balance=0; //instance variable
	public void setBalance(int amount)
	{
		if(amount > 0)
		balance =amount;
	}
	
	public int getBalance()
	{
		
		return(balance);
	}

	public void setBalance(int amount) {
		// TODO Auto-generated method stub
		
	}

}
