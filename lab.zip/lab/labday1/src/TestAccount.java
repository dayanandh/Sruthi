
public class TestAccount {

	public static void main(String[] args) {
		
		Account account = new Account();
		Account account2 = new Account();
		
		account.setBalance(1000);
		int amt=account.getBalance();
		System.out.println(amt);
		
		account.setBalance(4000);
		amt=account2.getBalance();
		System.out.println(amt);

	}

}
