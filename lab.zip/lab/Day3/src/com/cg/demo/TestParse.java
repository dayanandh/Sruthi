package com.cg.demo;

public class TestParse 
{

	public static void main(String[] args) 
	{
		int mobile=9898989;
		
		String str=String.valueOf(mobile);
		
	}
}
