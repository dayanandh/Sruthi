package com.cg.demo;

public class TestPattern {

}
