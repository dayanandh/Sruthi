package com.cg.demo;

public class TestShape
{
	public static void main(String[] args)
	{
		Shape shape=null;
		
		shape=new Circle();
		shape.draw();
		
		shape=new Rectangle();
		shape.draw();
		
		shape=new Car();
		shape.draw();
		
	}

}
