package com.cg.demo;

public class Truck extends Vehicle
{
	
	@Override
	public void speed()
	{
		System.out.println("Truck Speed");
	}
	@Override
	public void milage()
	{
		System.out.println("truck milage");
	}
	public void startLoading()
	{
		System.out.println("Start loading");
	}

	public void stopLoading()
	{
		System.out.println("stop loading");
	}
}
