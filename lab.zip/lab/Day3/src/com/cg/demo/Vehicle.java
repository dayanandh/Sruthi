package com.cg.demo;

public abstract class Vehicle
{
	
	private int vehicleId;
	public abstract void speed();
	public abstract void milage();
	
	
	public int getVehicleId()
	{
		return vehicleId;
	}
	public void setVehicleId(int vehicleId)
	{
		this.vehicleId = vehicleId;
	}
	
	public void display()
	{
		System.out.println("CLASS NAME OF VEHICLE");
	}
	
	

}
