package com.cg.demo;

public interface CircularShape extends Shape
{
	
	

}
