package com.cg.pk2;

import com.cg.pk1.Test;

public class TestInheritance extends Test
{
	
	public void display()
	{
		//defaultField=10;
		publicField=90;
		protectedField=90;
		//privateField =100;
	}

}
