package com.cg.ems.bean;

public class Employee 
{
	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	private String employeeDesignation;
	private long employeeMobile;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public String getEmployeeDesignation() {
		return employeeDesignation;
	}
	public void setEmployeeDesignation(String employeeDesignation) {
		this.employeeDesignation = employeeDesignation;
	}
	public long getEmployeeMobile() {
		return employeeMobile;
	}
	public void setEmployeeMobile(long employeeMobile) {
		this.employeeMobile = employeeMobile;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeSalary=" + employeeSalary
				+ ", employeeDesignation=" + employeeDesignation
				+ ", employeeMobile=" + employeeMobile + "]";
	}
	
	

}
