package com.cg.ems.service;

import com.cg.ems.bean.Employee;

public interface IEmployeeService
{

	public void calculateSalary(Employee bean);
	public boolean validateEmployee(Employee bean);
}
