package com.cg.ems.service;

import com.cg.ems.bean.Employee;

public class EmployeeServiceImp1 implements IEmployeeService

{
	@Override
	public void calculateSalary(Employee bean)
	{
		
		String design=bean.getEmployeeDesignation();
		
		if(design.equals("Manager"))
		{
			bean.setEmployeeSalary(15000);
		}
		else if(design.equals("clerk"))
		{
			bean.setEmployeeSalary(10000);
		}
		else
		{
			bean.setEmployeeSalary(8000);
		}
		
		
	}

	@Override
	public boolean validateEmployee(Employee bean) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean validateName(String name)
	{
		return (false);
	}
	public boolean validateDesign(String desig)
	{
		return (false);
	}
	public boolean validateMobile(String mobile)
	{
		return (false);
	}
}
