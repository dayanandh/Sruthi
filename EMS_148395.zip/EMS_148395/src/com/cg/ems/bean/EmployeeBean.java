package com.cg.ems.bean;

import java.time.LocalDate;

public class EmployeeBean 
{

	private int employeeId;
	private String employeeName;
	private String phoneNumber;
	private LocalDate employeeDoj;
	private String city;
	private String email;
	private String pincode;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getEmployeeDoj() {
		return employeeDoj;
	}
	public void setEmployeeDoj(LocalDate employeeDoj) {
		this.employeeDoj = employeeDoj;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "EmployeeBean [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", phoneNumber=" + phoneNumber
				+ ", employeeDoj=" + employeeDoj + ", city=" + city
				+ ", email=" + email + ", pincode=" + pincode + "]";
	}
	
	
}
