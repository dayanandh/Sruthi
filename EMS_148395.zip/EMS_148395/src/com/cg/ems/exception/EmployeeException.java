package com.cg.ems.exception;

public class EmployeeException extends Exception
{
	public EmployeeException(String message)
	{
		super(message);
	}

}
