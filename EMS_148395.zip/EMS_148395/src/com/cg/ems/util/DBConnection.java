package com.cg.ems.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ems.exception.EmployeeException;



public class DBConnection
{

	public static Connection getConnection() throws EmployeeException
	{
		Connection con=null;
		String driver=null;
		String jdbcurl=null;
		String user=null;
		String pass=null;
		try
		{
			
			Properties prop = new Properties();
			FileReader fr = new FileReader("resources/jdbc.properties");
			prop.load(fr);
			driver = prop.getProperty("driver");
			jdbcurl = prop.getProperty("jdbcurl");
			user = prop.getProperty("user");
			pass = prop.getProperty("pass");
			Class.forName(driver); // load and register
		
			con=DriverManager.getConnection(jdbcurl, user, pass);
		}
		catch(IOException e)
		{
			con=null;
			throw new EmployeeException(e.toString());
		}
		
		catch(ClassNotFoundException e)
		{
			con=null;
			throw new EmployeeException(e.toString());
		}
		catch(SQLException e)
		{
			con=null;
			throw new EmployeeException(e.toString());
		}
		return (con);
	}

}
