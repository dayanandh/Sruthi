package com.cg.ems.dao;

public interface QuerryMapper 
{

	public static final String INSERT_QRY="insert into emp_tbl values(emp_seq.nextval,?,?,sysdate,?,?,?)";
	
	public static final String SEARCH_QRY="select emp_id,emp_name,phone_number,emp_doj,city,email,pincode from emp_tbl where emp_id=?";
	
	public static final String SEQUENCE_QRY="select emp_seq.currval from dual";
	
	public static final String DELETE_QRY="delete from emp_tbl where emp_id=?";
	
	public static final String VIEW_QRY="select emp_id,emp_name,phone_number,emp_doj,city,email,pincode from emp_tbl";
}
