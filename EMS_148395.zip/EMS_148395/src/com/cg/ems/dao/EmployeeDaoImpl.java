package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;



public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int employeeId=0;
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QuerryMapper.INSERT_QRY);
			pstmt.setString(1, bean.getEmployeeName());
			pstmt.setString(2,bean.getPhoneNumber());
			pstmt.setString(3, bean.getCity());
			pstmt.setString(4, bean.getEmail());
			pstmt.setString(5, bean.getPincode());
			
			int status = pstmt.executeUpdate();
			
			if(status > 0)
			{
				pstmt = con.prepareStatement(QuerryMapper.SEQUENCE_QRY);
				
				ResultSet rst =pstmt.executeQuery();
				
				if(rst.next())
				{
					employeeId = rst.getInt(1);
				}
				else
				{
					throw new EmployeeException("Failed to get values from sequence");
				
				}
			}
			else
			{
				throw new EmployeeException("Faied to insert Employee");
			}
		} catch (SQLException e)
		{
			
			throw new EmployeeException(e.toString());
		}
		
		return employeeId;
	}

	@Override
	public EmployeeBean findEmployeeById(int employeeId) throws EmployeeException {
		EmployeeBean bean=null;
		
		
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QuerryMapper.SEARCH_QRY);
			
			pstmt.setInt(1, employeeId);
			ResultSet rst = pstmt.executeQuery();
			
			if( rst.next())
			{
				bean = new EmployeeBean();
				bean.setEmployeeId(rst.getInt("emp_id"));
				bean.setEmployeeName(rst.getString("emp_name"));
				bean.setPhoneNumber(rst.getString("phone_number"));
				bean.setEmployeeDoj(rst.getDate("emp_doj").toLocalDate());
				bean.setCity(rst.getString("city"));
				bean.setEmail(rst.getString("email"));
				bean.setPincode(rst.getString("pincode"));
			}
			else
			{
				throw new EmployeeException("Employee not found");
			}
		} catch (SQLException e)
		{
			
			throw new EmployeeException(e.toString());
		}
		
		
		return bean;
	}

}
