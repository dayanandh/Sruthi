package com.cg.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.exception.EmployeeException;


public class EmployeeServiceImpl implements IEmployeeService
{
	private IEmployeeDao employeeDao = new EmployeeDaoImpl();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException 
	{
		if(bean.getPincode().equals("590006"))
        {
            bean.setCity("Mumbai");
        }
        else if(bean.getPincode().equals("879999"))
        {
            bean.setCity("Delhi");
        }
        else if(bean.getPincode().equals("989999"))
        {
            bean.setCity("Chennai");
        }
        else
            bean.setCity("Unknown");
        int id = employeeDao.addEmployee(bean);
        return id;

	}

	@Override
	public EmployeeBean findEmployeeById(int employeeId)
			throws EmployeeException {
		
			EmployeeBean bean = employeeDao.findEmployeeById(employeeId);
		
		return bean;
	}

	@Override
	public boolean validateEmployee(EmployeeBean bean) throws EmployeeException {
		
		boolean flag =true;
		
		List<String> list=new ArrayList<String>();
		
		if(!validateName(bean.getEmployeeName()))
		{
			list.add("name should be minimum of 3 char ");
		
		}
		if(! validatePhoneNumber(bean.getPhoneNumber()))
		{
			list.add("phone number should be 10 digits \n");
		}
		if(! validateEmail(bean.getEmail()))
		{
			list.add("enter valid emailid with @ . \n");
		}
		if(! list.isEmpty())
		{
			throw new EmployeeException("Validation Fail "+list);
		}
		if(validateName(bean.getEmployeeName()) && validatePhoneNumber(bean.getPhoneNumber()) && validateEmail(bean.getEmail()))
        {
            return true;
        }
        else
        {
            return false;
        }
		
		
	}
	

	private boolean validatePhoneNumber(String name)
	{
            String input = name;
            Pattern pattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
            Matcher matcher= pattern.matcher(input);
            return matcher.matches();
        
		
	}

	private boolean validateEmail(String email) 
	{
		String emailRegex ="^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@" +"(?:[a-zA-Z0-9-]+\\.)+[a-z "+"A-Z]{2,7}$";
		Pattern pattern = Pattern.compile(emailRegex);
		if(email== null)
			return false;
			return pattern.matcher(email).matches();

	}

	

	public boolean validateName(String name)
	{
		String input = name;
		
		Pattern pattern = Pattern.compile("[A-Za-z]{3,}$");
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}
	

}
