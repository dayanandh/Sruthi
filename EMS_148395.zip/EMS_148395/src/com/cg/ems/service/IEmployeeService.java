package com.cg.ems.service;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;


public interface IEmployeeService
{

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public  EmployeeBean findEmployeeById(int employeeId)throws EmployeeException;
	public boolean validateEmployee(EmployeeBean bean) throws EmployeeException;
}
