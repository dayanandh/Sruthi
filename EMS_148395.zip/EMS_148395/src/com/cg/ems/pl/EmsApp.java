package com.cg.ems.pl;

import java.util.Scanner;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;


public class EmsApp 
{

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		EmployeeBean bean = new EmployeeBean();

		IEmployeeService service = new EmployeeServiceImpl();//important

		while (true) {
			System.out.println("1.ADD Employee");
			System.out.println("2.find Employee");
			System.out.println("3. exit");
			System.out.println("Enter your choice");

			int choice = Integer.parseInt(scanner.nextLine());

			switch (choice) {
			case 1:
				System.out.println("Enter Employee name");
				String name = scanner.nextLine();
				System.out.println("Enter Phonenumber");
				String phonenumber = scanner.nextLine();
				System.out.println("Enter Email");
				String email = scanner.nextLine();
				System.out.println("Enter pincode");
				String pincode = scanner.nextLine();
				bean = new EmployeeBean();
				bean.setEmployeeName(name);
				bean.setPhoneNumber(phonenumber);
				bean.setEmail(email);
				bean.setPincode(pincode);
				try {

					if (service.validateEmployee(bean)) {
						int id = service.addEmployee(bean);
						System.out.println("Added Successfully");
						System.out.println("ID = " + id);
					}
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter Employee ID");
				int pid = Integer.parseInt(scanner.nextLine());
				try {
					bean = service.findEmployeeById(pid);
					System.out.println("Employee found");
					System.out.println(bean);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("Thank you");
				System.exit(0);

			default:
				System.out.println("Invalid choice");
			}
		}
	}


}
