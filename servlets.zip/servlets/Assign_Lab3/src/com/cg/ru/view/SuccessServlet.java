package com.cg.ru.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/success")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//int mobileid = (Integer)request.getAttribute("mobileid");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		RequestDispatcher disp = request.getRequestDispatcher("HeaderServlet");
		disp.include(request, response);
		//out.print("<h2>Mobile detailed recorded successfully with id"+mobileid+"</h2>");
		out.print("<h2>User registration success</h2>");
		
	}

}