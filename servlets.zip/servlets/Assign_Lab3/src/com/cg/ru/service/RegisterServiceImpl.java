package com.cg.ru.service;


import com.cg.ru.Exception.RegisterException;
import com.cg.ru.dao.RegisterDao;
import com.cg.ru.dao.RegisterDaoImpl;
import com.cg.ru.dto.RegisterBean;

public class RegisterServiceImpl  implements RegisterService
{
	
	RegisterDao rdao=new RegisterDaoImpl();
	@Override
	public int insertRegisteruser(RegisterBean bean) throws RegisterException {
		
		return rdao.insertRegisteruser(bean);
	}

}
