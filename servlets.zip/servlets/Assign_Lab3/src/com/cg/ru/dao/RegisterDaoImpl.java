package com.cg.ru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.ru.Exception.RegisterException;
import com.cg.ru.dto.RegisterBean;

public class RegisterDaoImpl implements RegisterDao
{
	Connection conn=null;

	@Override
	public int insertRegisteruser(RegisterBean bean) throws RegisterException {
		String sql="Insert into registeredusers values(?,?,?,?,?,?)";
	    System.out.println(bean);
		int regusers=0;
		try{
			conn = DBUtil.getConnection();
			PreparedStatement pst= conn.prepareStatement(sql);
			pst.setString(1, bean.getFirstName());
			pst.setString(2, bean.getLastName());
			pst.setString(3, bean.getPassword());
			pst.setString(4, bean.getGender());
			pst.setString(5, bean.getSkillSet());
			pst.setString(6, bean.getCity());
			regusers = pst.executeUpdate();
			if(regusers==0)
			{
				throw new RegisterException("problem in inserting the date");
			}
			
		}
		catch(SQLException e)
		{
			throw new RegisterException("problem in inserting the date"+e.getMessage());
		}
		return regusers;
	}

	
}
