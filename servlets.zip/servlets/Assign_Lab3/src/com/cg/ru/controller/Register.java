package com.cg.ru.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ru.Exception.RegisterException;
import com.cg.ru.dto.RegisterBean;
import com.cg.ru.service.RegisterService;
import com.cg.ru.service.RegisterServiceImpl;



@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request ,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RegisterService mser=new RegisterServiceImpl();
		RegisterBean bean= new RegisterBean();
		bean.setFirstName(request.getParameter("fname"));
		bean.setLastName(request.getParameter("lname"));
		bean.setPassword(request.getParameter("pass"));
		bean.setGender(request.getParameter("gender"));
		String Arr[]=request.getParameterValues("skill");
		StringBuilder str= new StringBuilder();
		for(String a:Arr)
		{
			str.append(a);
			str.append(",");
	
		}
		str.deleteCharAt(str.length()-1);
		String skill = str.toString();
		bean.setSkillSet(skill);
		bean.setCity(request.getParameter("city"));

		
		String url="";
		try{
			System.out.println(bean);
			int fla = mser.insertRegisteruser(bean);
			if(fla>0)
			{
			url="success";
				System.out.println("success");
			}

		}
		catch(RegisterException e)
		{
			request.setAttribute("error", e.getMessage());
			e.printStackTrace();
			url="failure";
		}
		RequestDispatcher disp=request.getRequestDispatcher(url);
		disp.forward(request, response);
		
	}
	

	
}
