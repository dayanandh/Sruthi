function getDetails(){
cname=document.myform.cname.value;
ageType=document.myform.age.value;
bookType=document.myform.product.value;
numberOfDays=document.myform.totaldays.value;
newwin = window.open("","window name","status=0,toolbar=1,menubar=1");


if(document.myform.product.value == "select anu option")
{
	alert("rtrt");
}
/*if(cname.length<5)
{
alert("please give minimum 5 characters in customer name");


else
{

*/
if(numberOfDays < 30 && numberOfDays>0)
{
cost= 5 * numberOfDays;
newwin.document.write(cname+" of category " + ageType + " has taken "+bookType +" for "+ numberOfDays +"days which costed of amount"+ cost);

else
{
alert("days need to be less than 30");
}
}
return false;
}
