function amount() {
	var customerName = document.getElementById("name").value;
	var phNo=document.getElementById("phNumber").value;
	var mailId= document.getElementById("emailId").value;
	var movieName =document.getElementById("movie").value;
	var classType= document.getElementById("class").value;
	var ticket =document.getElementById("tickets").value;
	
	var amount;
	var tax = 12/100;
	var ticketPrice;
	if(classType == "Gold") {
		ticketPrice = ticket * 300;
		amount = ticketPrice + (ticketPrice * tax);
	}
	else
	{
		ticketPrice = ticket * 250;
		amount = ticketPrice + (ticketPrice * tax);
	
	}
		var win = window.open("","toolbar,status,resizable","height=300,width=300");
		win.document.write("Customer Name : "+customerName+"<br>"+"Mobile Number : "+phNo+"<br>"+"No of Tickets :"+ticket+"<br>"+"Payable Amount :"+amount);
		
		return false;
}