package com.cg.mps.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;



import org.junit.BeforeClass;
import org.junit.Test;



import com.cg.mps.bean.MobilesBean;
import com.cg.mps.bean.PurchaseDetailsBean;
import com.cg.mps.dao.IMobilePurchaseDao;
import com.cg.mps.dao.MobilePurchaseDaoImpl;
import com.cg.mps.exception.MobileException;

public class MobilePurchaseDaoTest {

	static IMobilePurchaseDao mobilepurchaseDao;
	static MobilesBean Mbean;
	static PurchaseDetailsBean Pbean;
	
	@BeforeClass
	public static void init()
	{
		mobilepurchaseDao = new MobilePurchaseDaoImpl();
		Mbean = new MobilesBean();
		Pbean = new PurchaseDetailsBean();
	}
	
	@Test
	public void testaddCustomer() throws MobileException{
		Pbean.setCustomerName("Billa David");
		Pbean.setCustomerMailId("abc@gg.com");
		Pbean.setCustomerPhoneNo("9876543210");
		Pbean.setMobileId(1001);
		int id = mobilepurchaseDao.addCustomer(Pbean);
		assertTrue(id > 0);
		
	}
	@Test
	public void testViewAllMobiles() throws MobileException {
		assertNotNull(mobilepurchaseDao.viewAllMobiles());
	}
		
	}
