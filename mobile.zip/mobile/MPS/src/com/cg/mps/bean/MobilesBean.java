package com.cg.mps.bean;

public class MobilesBean {
	
	private int MobileId;
	private String MobileName;
	private int MobilePrice;
	
	
	public int getMin() {
		return min;
	}
	public void setMin(int min) {
		this.min = min;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	private int MobileQuantity;
	private int min;
	private int max;
	
	
	
	
	
	public int getMobileId() {
		return MobileId;
	}
	public void setMobileId(int mobileId) {
		MobileId = mobileId;
	}
	public String getMobileName() {
		return MobileName;
	}
	public void setMobileName(String mobileName) {
		MobileName = mobileName;
	}
	public int getMobilePrice() {
		return MobilePrice;
	}
	public void setMobilePrice(int mobilePrice) {
		MobilePrice = mobilePrice;
	}
	public int getMobileQuantity() {
		return MobileQuantity;
	}
	public void setMobileQuantity(int mobileQuantity) {
		MobileQuantity = mobileQuantity;
	}
	@Override
	public String toString() {
		return "Mobiles [MobileId=" + MobileId + ", MobileName=" + MobileName
				+ ", MobilePrice=" + MobilePrice + ", MobileQuantity="
				+ MobileQuantity + "]";
	}
	

}
