package com.cg.mps.bean;

public class PurchaseDetailsBean {

	private int PurchaseId;
	private String CustomerName;
	private String CustomerMailId;
	private String CustomerPhoneNo;
	private String PurchaseDate;
	private int MobileId;
	
	public int getPurchaseId() {
		return PurchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		PurchaseId = purchaseId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getCustomerMailId() {
		return CustomerMailId;
	}
	public void setCustomerMailId(String customerMailId) {
		CustomerMailId = customerMailId;
	}
	public String getCustomerPhoneNo() {
		return CustomerPhoneNo;
	}
	public void setCustomerPhoneNo(String customerPhoneNo) {
		CustomerPhoneNo = customerPhoneNo;
	}
	public String getPurchaseDate() {
		return PurchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		PurchaseDate = purchaseDate;
	}
	public int getMobileId() {
		return MobileId;
	}
	public void setMobileId(int mobileId) {
		MobileId = mobileId;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [PurchaseId=" + PurchaseId + ", CustomerName="
				+ CustomerName + ", CustomerMailId=" + CustomerMailId
				+ ", CustomerPhoneNo=" + CustomerPhoneNo + ", PurchaseDate="
				+ PurchaseDate + ", MobileId=" + MobileId + "]";
	}
	
}
