package com.cg.hms.dto;





import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;





@Entity
@Table(name="bookingdetails")
public class RegisterBean 
{
	@Id
	@SequenceGenerator(name="bkid",sequenceName="bookingseq",allocationSize=1)
	@GeneratedValue(generator="bkid",strategy=GenerationType.SEQUENCE)
	private int id;
	
	@Column(name="customername")
	@NotEmpty(message="Customer Name Is Mandatory")
	private String customerName;
	
	@Column(name="noofrooms")
	@NotNull(message="Cannot be empty")
	private int noofrooms;
	
	@Transient
	private String hotelname;
	
	@Column
	private int hotelid;
	@Future
	//@NotEmpty(message="Date cannot be empty")
	@Column(name="fromdate")
	Date fromDate;
	
	@Future
	@Column(name="todate")
	//@NotEmpty(message="Date cannot be empty")
	Date  toDate;
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getNoofrooms() {
		return noofrooms;
	}
	public void setNoofrooms(int noofrooms) {
		this.noofrooms = noofrooms;
	}
	public int getHotelid() {
		return hotelid;
	}
	public void setHotelid(int hotelid) {
		this.hotelid = hotelid;
	}

	
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}


	
	@Override
	public String toString() {
		return "RegisterBean [id=" + id + ", customerName=" + customerName
				+ ", noofrooms=" + noofrooms + ", hotelname=" + hotelname
				+ ", hotelid=" + hotelid + ", fromDate=" + fromDate
				+ ", toDate=" + toDate + "]";
	}
}
