package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;

@Service("loginSer")
public class LoginService implements ILoginService{

	@Autowired
	ILoginDao loginDao;
	
	
	public ILoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public boolean isUserExist(String unm) {

		return loginDao.isUserExist(unm);
	}

	@Override
	public boolean isValid(Login log) {
		
		return loginDao.isValid(log);
	}

	@Override
	public RegisterDTO addUserDetails(RegisterDTO userDto) {
		
		return loginDao.addUserDetails(userDto);
	}

	@Override
	public Login addUser(Login logDto) {
		
		return loginDao.addUser(logDto);
	}

	@Override
	public ArrayList<RegisterDTO> getAllUsers() {
		
		return loginDao.getAllUsers();
	}

	@Override
	public RegisterDTO update(RegisterDTO userDto, String updfname) {
	
		return loginDao.update(userDto, updfname);
	}

	@Override
	public RegisterDTO delete(String uname) {
		
		return loginDao.delete(uname);
	}

	
}
