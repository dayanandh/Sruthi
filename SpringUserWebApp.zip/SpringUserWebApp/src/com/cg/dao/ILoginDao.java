package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;

public interface ILoginDao {

	public boolean isUserExist(String unm);
	public boolean isValid(Login log);
	public RegisterDTO addUserDetails(RegisterDTO userDto);
	public Login addUser(Login logDto);
	public ArrayList<RegisterDTO> getAllUsers();
	public RegisterDTO update(RegisterDTO userDto,String updfname);
	public RegisterDTO delete(String uname);
}
