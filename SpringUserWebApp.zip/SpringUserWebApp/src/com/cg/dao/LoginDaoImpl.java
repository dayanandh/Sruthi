package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;
import com.cg.util.MyStringDateUtil;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String unm) {
	
		Login log=entityManager.find(Login.class,unm);
		System.out.println("In dao......"+log);
		if(log!=null)
		{
			return true;
		}
		else
		{
			return false;
			
		}
		
	}

	@Override
	public boolean isValid(Login log) {
	
		Login lg=entityManager.find(Login.class, log.getUsername());
		if(log.getPassword().equalsIgnoreCase(lg.getPassword()))
		{
			return true;
		}
		else
		{
			return false;
		}
			
	}

	@Override
	public RegisterDTO addUserDetails(RegisterDTO userDto) {
		
		System.out.println("In addUserDetails");
		String mySkills=MyStringDateUtil.fromArrayToCommaSeparatedString(userDto.getSkillSets());
		userDto.setSkillSetStr(mySkills);
		entityManager.persist(userDto);
		entityManager.flush();
		System.out.println("user Details added");
		return userDto;
	}

	@Override
	public Login addUser(Login logDto) {
		
		System.out.println("In dao addUser function");
		entityManager.persist(logDto);
		entityManager.flush();
		System.out.println("UserID and Password is added in dao"+logDto);
		return logDto;
	}

	@Override
	public ArrayList<RegisterDTO> getAllUsers() {
		
		String qry="SELECT reg FROM RegisterDTO reg";
		TypedQuery<RegisterDTO> tq=entityManager.createQuery(qry,RegisterDTO.class);
		ArrayList<RegisterDTO> userL=(ArrayList)tq.getResultList();
		return userL;
	}

	@Override
	public RegisterDTO update(RegisterDTO userDto,String updfname) {
		
		
		RegisterDTO reg= entityManager.find(RegisterDTO.class, userDto.getUname());
		System.out.println(reg);
		reg.setFname(updfname);
		
		RegisterDTO reg1= entityManager.merge(reg);
		return reg1;
	}

	@Override
	public RegisterDTO delete(String uname) {
		
		RegisterDTO regd=entityManager.find(RegisterDTO.class, uname);
		entityManager.remove(regd);
		return regd;
	}

}

