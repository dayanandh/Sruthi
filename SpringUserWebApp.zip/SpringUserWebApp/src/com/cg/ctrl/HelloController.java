package com.cg.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@RequestMapping(value="/ShowIndexPage" , method=RequestMethod.GET)
	public String dispIndexPage()
	{
		return "Index";
	}
	
	@RequestMapping(value="/ShowGreetPage", method=RequestMethod.GET)
	public ModelAndView dispGreetPage()
	{
		String name="Lavanya Tirumani";
		ModelAndView modelview=new ModelAndView("GreetMe","NameObj",name);
		return modelview;
	}
}
