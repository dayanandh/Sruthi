package com.cg.ctrl;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dto.Login;
import com.cg.service.ILoginService;

@Controller
@RequestMapping("logctrl")
public class LoginController {
	
	@Autowired
	ILoginService loginSer;

	public ILoginService getLoginSer() {
		return loginSer;
	}

	public void setLoginSer(ILoginService loginSer) {
		this.loginSer = loginSer;
	}

	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String dispLoginPage(Model model)
	{
		Login  lg=new Login();
	//	lg.setUsername("Enter Name Here:");        text in textbox
		model.addAttribute("loginUser",lg);
		return "Login";
	}
	
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String validateLogin(@Valid
								@ModelAttribute("loginUser")Login lgg, 
								BindingResult result, 
								Model model)
	{
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		{
		String un=lgg.getUsername();
		String pw=lgg.getPassword();
		if(loginSer.isUserExist(un))
		{
			if(loginSer.isValid(lgg))
			{
				return "Success";
			}
			else
			{
				String msg="Password is Incorrect";
				model.addAttribute("ErrorMsgObj", msg);
				return "Error";
			}
		}
		
		else
		{
			String msg="User Does Not Exist";
			model.addAttribute("ErrorMsgObj", msg);
		//	return "Register";
			return "redirect:/dispRegPage.obj";
		}
		}
	}
}
