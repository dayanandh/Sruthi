package com.cg.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;
import com.cg.dto.RegisterDTO;
import com.cg.service.ILoginService;

@Controller

public class RegisterController {

	@Autowired
	ILoginService loginSer;
	ArrayList<String> cityList=null;
	ArrayList<String> skillSetList=null;
	public ILoginService getLoginSer() {
		return loginSer;
	}

	public void setLoginSer(ILoginService loginSer) {
		this.loginSer = loginSer;
	}
	
	@RequestMapping(value="/dispRegPage",method=RequestMethod.GET)
	public String showRegPage(Model model)
	{
	    cityList=new ArrayList<String>();
	    skillSetList=new ArrayList<String>();
	    
	    cityList.add("Mumbai");
	    cityList.add("Pune");
	    cityList.add("Noida");
	    cityList.add("Hyderabad");
	    
	    skillSetList.add("C");
	    skillSetList.add("C++");
	    skillSetList.add("Java");
	    skillSetList.add("Oracle");
	    
		RegisterDTO rd=new RegisterDTO();
		model.addAttribute("user", rd);
		model.addAttribute("skillsList", skillSetList);
		model.addAttribute("cList", cityList);
		
		return "Register";
	}
	
	@RequestMapping(value="/insertUserDetails",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute("user")RegisterDTO rd,
								BindingResult result,
								Model model)
	{
		Login log=new Login();
		log.setUsername(rd.getUname());
		log.setPassword(rd.getPwd());
		
		System.out.println("In Reg Ctrl "+log+" : "+rd);
		loginSer.addUser(log);
		loginSer.addUserDetails(rd);
		
	//	return "ListAllUsers";
		return "redirect:/ShowListAllUser.obj";
	}
	
	@RequestMapping(value="/ShowListAllUser",method=RequestMethod.GET)
	public String dispUserListPage(Model model)
	{
		ArrayList<RegisterDTO> usr1=loginSer.getAllUsers();
		model.addAttribute("UserListObj",usr1);
		return "ListAllUsers";
	}
	
	@RequestMapping(value="/dispEditUser",method=RequestMethod.GET)
	public String dispEditUser(@RequestParam(value="uid") String uid,@RequestParam(value="fname") String fname,Model model)
	{
		System.out.println(uid);
		RegisterDTO reg1=new RegisterDTO();
		model.addAttribute("UpdateUser",reg1);
		model.addAttribute("update", uid);
		model.addAttribute("updfirstname", fname);
		return "UpdateFName";
		
	}
	
	@RequestMapping(value="/updateUser1",method=RequestMethod.GET)
	public String updateUser(@ModelAttribute("UpdateUser")RegisterDTO rd1,BindingResult result,Model model)
	{
		String updfname=rd1.getFname();
		//System.out.println(updfname);
		String username=rd1.getUname();
		//System.out.println(username);
		RegisterDTO reg2=loginSer.update(rd1, updfname);
	//	model.addAttribute("object", reg2);
		return "redirect:/ShowListAllUser.obj";
		
	}
	
	@RequestMapping(value="/deleteuser",method=RequestMethod.GET)
	public String deleteUser(@RequestParam(value="uid") String uid,Model model)
	{
		
		RegisterDTO del=new RegisterDTO();
		loginSer.delete(uid);
		return "redirect:/ShowListAllUser.obj";
	}
	
	
}
