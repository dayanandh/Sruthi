package assignment4;

public class Person1 {
	
	String name;
	float age;
	public Person1(String n1,float a)
	{
	name=n1;
	age=a;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public float getAge() {
	return age;
	}
	public void setAge(float age) {
	this.age = age;
	}
	}

