package assignment4;

public class Account {
		long accNum;
		double balance;
		Person1 accHolder;
		public Account()
		{
		}
		public Account(double bal,Person1 acc)
		{
		balance=bal;
		accHolder=acc;
		accNum=(long)(Math.random()*100000);
		}
		public void display()
		{
		System.out.println(balance);
		System.out.println(accHolder.name);
		System.out.println(accHolder.age);
		System.out.println(accNum);
		}
		public double deposit(double bal1)
		{
		balance=balance+bal1;
		return balance;
		}
		public double withdraw(double bal2)
		{
		balance=balance-bal2;
		return balance;
		}
		public long getAccNum() {
		return accNum;
		}
		public void setAccNum(long accNum) {
		this.accNum = accNum;
		}
		public double getBalance() {
		return balance;
		}
		public void setBalance(double balance) {
		this.balance = balance;
		}
		public Person1 getAccHolder() {
		return accHolder;
		}
		public void setAccHolder(Person1 accHolder) {
		this.accHolder = accHolder;
		}
		}

