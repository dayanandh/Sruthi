package assignment4;

public class Associate {
	
	public static void main(String[] args) {
		Account b1=new Account(2000,new Person1("Smith",60));
		Account b2=new Account(3000,new Person1("Kathy",45));
		b1.deposit(2000);
		b2.withdraw(2000);
		b1.display();
		b2.display();
		}
		
}
