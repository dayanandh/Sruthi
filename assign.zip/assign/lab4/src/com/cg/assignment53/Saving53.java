package com.cg.assignment53;

import assignment4.Person1;

public class Saving53 extends Account1 {
	final double minBalance=500;
	public Saving53(double bal,Person1 acc)
	{
	balance=bal;
	accHolder=acc;
	accNum=(long)(Math.random()*100000);
	}
	public void withdraw(double bal2)
	{
	if(balance>=minBalance)
	{
	double amount=bal2;
	balance=balance-bal2;
	}
	else
	{
	System.out.println("Invalid");
	}
	}
}
