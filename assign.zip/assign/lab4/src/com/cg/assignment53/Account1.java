package com.cg.assignment53;

import assignment4.Person1;

public abstract class Account1 {
	
	long accNum;
	double balance;
	Person1 accHolder;
	public Account1()
	{
	}
	public Account1(double bal,Person1 acc)
	{
	balance=bal;
	accHolder=acc;
	accNum=(long)(Math.random()*100000);
	}
	public void display()
	{
	System.out.println(balance);
	System.out.println(accHolder.getName());
	System.out.println(accHolder.getAge());
	System.out.println(accNum);
	}
	public double deposit(double bal1)
	{
	balance=balance+bal1;
	return balance;
	}
	public abstract void withdraw(double bal2);
	public long getAccNum() {
	return accNum;
	}
	public void setAccNum(long accNum) {
	this.accNum = accNum;
	}
	public double getBalance() {
	return balance;
	}
	public void setBalance(double balance) {
	this.balance = balance;
	}
	public Person1 getAccHolder() {
	return accHolder;
	}
	public void setAccHolder(Person1 accHolder) {
	this.accHolder = accHolder;
	}
}
