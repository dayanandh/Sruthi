package com.cg.assignment53;



import assignment4.Person1;

public class SavingDisplay {
	public static void main(String[] args)
	{
	Saving53 b1=new Saving53(3000,new Person1("Smith",60));
	b1.withdraw(2000);
	b1.display();
}
}
