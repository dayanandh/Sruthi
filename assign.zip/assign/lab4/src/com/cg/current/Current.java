package com.cg.current;

import assignment4.Account;
import assignment4.Person1;

public class Current extends Account{
	
	final double overdraft_limit=-20000;
	public Current(double bal,Person1 acc)
	{
	setBalance(bal);
	setAccHolder(acc);
	setAccNum((long)(Math.random()*100000));
	}
	public boolean checkOverride(double amount)
	{
	if(amount<overdraft_limit)
	{
	return false;
	}
	else
	{
	return true;
	}
	}
	public double withdraw(double amount)
	{
	if(checkOverride(this.getBalance()-amount))
	{
	setBalance(getBalance()-amount);
	}
	else
	{
	System.out.println("Invalid");
	super.withdraw(amount);
	}
	return amount;
	}
}
