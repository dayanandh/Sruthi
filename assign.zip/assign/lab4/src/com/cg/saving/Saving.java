package com.cg.saving;

import assignment4.Account;
import assignment4.Person1;

public class Saving extends Account{
final double minBalance=500;
public Saving(double bal,Person1 acc)
{
setBalance(bal);
setAccHolder(acc);
setAccNum((long)(Math.random()*100000));
}
public double withdraw(double bal2)
{
if(getBalance()>=minBalance)
{
double amount=bal2;
super.withdraw(amount);
}
return minBalance;
}

}