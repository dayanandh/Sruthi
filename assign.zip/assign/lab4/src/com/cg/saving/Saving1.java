package com.cg.saving;

import assignment4.Person1;

public class Saving1 {
	public static void main(String[] args)
	{
	Saving b1=new Saving(2000,new Person1("Smith",60));
	b1.deposit(2000);
	b1.display();
	}
	
}
