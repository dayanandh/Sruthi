
public class TestCase {
	public void verify(String fname,String lname) throws NameException {
		if(fname.length()==0 && lname.length()==0) {
			throw new NameException("Names should not be blank");
		}
	}
}
