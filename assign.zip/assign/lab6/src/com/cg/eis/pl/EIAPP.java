package com.cg.eis.pl;

import java.util.*;

import com.cg.eis.bean.EmployeeBean;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

public class EIAPP {
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		EmployeeBean obj=null;
		IEmployeeService service = new EmployeeServiceImpl();
		while(true)
		{
		System.out.println("1.Add Employee Details");
		System.out.println("2.View Employee Insurance Scheme");
		System.out.println("3.View Employee Details");
		System.out.println("4.Exit");
		System.out.println("Enter your choice");
		int choice = scr.nextInt();
		switch(choice)
		{
		case 1:
		System.out.println("Enter employee name:");
		scr.nextLine();
		String employeeName=scr.nextLine();
		System.out.println("Enter employee designation:");
		String designation=scr.nextLine();
		System.out.println("Enter employee id:");
		int employeeId=scr.nextInt();
		System.out.println("Enter salary:");
		int salary=scr.nextInt();
		
		obj=new EmployeeBean();
		obj.setEmployeeName(employeeName);
		obj.setEmployeeId(employeeId);
		obj.setSalary(salary);
		obj.setDesignation(designation);
			try {
				service.addEmployee(obj);
			} catch (EmployeeException e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
			}
		break;
		case 2:
			try{
			service.insuranceScheme(obj);
			}
			catch(EmployeeException e){
				System.out.println(e.getMessage());
			}
			break;
		case 3:
			service.viewAllDetails(obj);
			
			}
		}
		}
	}


