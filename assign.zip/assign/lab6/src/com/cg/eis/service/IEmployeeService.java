package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.EmployeeBean;
import com.cg.eis.exception.EmployeeException;

public interface IEmployeeService {
	public  String insuranceScheme(EmployeeBean bean) throws EmployeeException;
	public String viewAllDetails(EmployeeBean bean) ;
	public String addEmployee(EmployeeBean bean) throws EmployeeException;
}
