import java.util.Scanner;




public class Exception1 {
	public static void main(String[] args) throws NameException{
		String firstName = null;
		String lastName = null;
		TestCase name = new TestCase();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter fname");
		firstName = sc.nextLine();
		System.out.println("enter lname");
		lastName = sc.nextLine();
		try {
		name.verify(firstName,lastName);
		}catch(NameException e) {
			System.out.println(e.getMessage());
		}
		
		
	}

}
