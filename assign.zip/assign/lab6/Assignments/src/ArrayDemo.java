import java.util.Arrays;


public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           int arr[] = new int[4];
           String[]str={"India","Mumbai","Airoli"};
           float []ftr = new float[]{1.1f,2.2f,3.3f};
           for(int i=0;i<arr.length;i++)
        	   System.out.println(arr[i]);
           
           //forEach loop
	      for(String var :str)
	      {
	    	  System.out.print(var);
	      }
           Arrays.sort(str);	
	       System.out.println("After Sorting");
	       for(String var:str)
	       {
	    	   System.out.println("var = "+var);
	       }
	}

}
