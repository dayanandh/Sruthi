import java.util.Scanner;
import java.util.regex.Pattern;


public class RegExpDemo {

	
	   public static void main(String[] args){
		   
		   Scanner sc = new Scanner(System.in);
		   System.out.println("enter name :");
		   String name = sc.next();
		   System.out.println("Enter contact");
		   String contact = sc.next();
		   Pattern pattname = Pattern.compile("[A-Z]{1}[a-z]{2,}");
		   Pattern pattContact = Pattern.compile("[7,8,9]{1}[0-9]{9}");
		   if(name.matches(pattname.toString()))
		   {
			   if(contact.matches(pattContact.toString()))
			   {
				   System.out.println("input is valid");
			   }
		   }
	   }
}
