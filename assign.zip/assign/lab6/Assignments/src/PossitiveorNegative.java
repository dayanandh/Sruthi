import java.util.Scanner;

public class PossitiveorNegative {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		// TODO Auto-generated method stub
        System.out.println("enter a number");  
		int Number=in.nextInt();
		if(Number > 0){
			System.out.println("Possitive number");
		}
		else
		{
			System.out.println("Negative number");
		}
	}

}
