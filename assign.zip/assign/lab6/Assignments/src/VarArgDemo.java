
public class VarArgDemo {
	
	static int add(int x, int...y)
	{
		int sum =0;
		for(int num : y)
		{
			sum = sum + num;
		}
		sum = sum + x;
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		int res = add(6);
		System .out.println("res = "+res);
		res = add(5,2);
		System.out.println("res = "+res);
		res = add(2,3,4);
		System.out.println("res = "+res); 
	}

}
