
public class Createphno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter mobile number");
		personPhonenum per = new personPhonenum("gvd","kishore",'m');
		System.out.println("mobile number "+per.phno);
        System.out.println("firstName= "+per.getFirstName());	
        System.out.println("lastName= "+per.getLastName());
        System.out.println("gender= "+per.getGender());
	}

}
