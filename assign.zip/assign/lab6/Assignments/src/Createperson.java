
public class Createperson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		personString per = new personString("gvd","kishore",'m');
         System.out.println("firstName= "+per.getFirstName());	
         System.out.println("lastName= "+per.getLastName());
         System.out.println("gender= "+per.getGender());
         }

}
