package com.cg.mps.dao;

public interface QueryMapper {

	public static String ADD_QUERY="insert into purchasedetails values(purchase_id.nextval,?,?,?,sysdate,?)";
	
	public static String SEQUENCE_QUERY = "select purchase_id.currval from dual";
	
	public static String VIEWALLMOBILES_QUERY = "select * from mobiles";
	
	public static String DELETE_QUERY = "delete from mobiles where mobileid=?";
	
	public static String PRICERANGE_QUERY="select * from mobiles where price between ? and ?";
	
	public static String UPDATE_QUANTITY_QUERY="update mobiles set quantity = quantity - 1 where mobileid = ?";
}
