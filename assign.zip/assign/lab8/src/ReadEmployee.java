import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class ReadEmployee {
	public static void main(String[] args) {
		try
		{
		FileOutputStream fos=new FileOutputStream("emp.dat");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		Employee e1=new Employee();
		e1.setId(10);
		e1.setName("Ankur");
		e1.setSalary(1000);
		e1.setDesignation("XYZ");
		oos.writeObject(e1);
		oos.close();
		}
		catch(FileNotFoundException e)
		{
		e.printStackTrace();
		}
		catch(IOException e)
		{
		e.printStackTrace();
		}
		try
		{
		FileInputStream fis=new FileInputStream("emp.dat");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Employee e2=(Employee) ois.readObject();
		System.out.println(e2.getDesignation()+" "+e2.getId()+" "+e2.getName()+" "+e2.getSalary());
		}
		catch(FileNotFoundException e)
		{
		e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
		e.printStackTrace();
		}
		catch(IOException e)
		{
		e.printStackTrace();
		}
		}
	}


