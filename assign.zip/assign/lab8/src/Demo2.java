import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("number.txt");
		Scanner sc;
		try {
		sc = new Scanner(file).useDelimiter(",");
		while(sc.hasNext())
		{
		int c=sc.nextInt();
		if(c%2==0)
		System.out.println(c);
		}
		} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}

	}

}
