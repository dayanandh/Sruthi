import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		try
		{
		FileInputStream fis = new FileInputStream("./resources/8.1.txt");
		int ch;
		while((ch=fis.read())!=-1)
		{
		char chr = (char)ch;
		sb.append(chr);
		}
		fis.close();
		}catch(FileNotFoundException e){
		e.printStackTrace();
		}catch(IOException e)
		{
		e.printStackTrace();
		}
		int len = sb.length();
		try {
		FileOutputStream fos = new FileOutputStream("./resources/8.1.txt");
		for(int i=len-1;i>=0;i--){
		fos.write((char)sb.charAt(i));
		}
		fos.close();
		}catch(FileNotFoundException e){
		e.printStackTrace();
		}catch(IOException e){
		e.printStackTrace();
		}

	}

}
