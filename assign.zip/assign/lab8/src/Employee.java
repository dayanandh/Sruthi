import java.io.Serializable;


public class Employee  implements Serializable{


		// TODO Auto-generated method stub
		int id;
		String name;
		int salary;
		String designation;
		public int getId() {
		return id;
		}
		public void setId(int id) {
		this.id = id;
		}
		public String getName() {
		return name;
		}
		public void setName(String name) {
		this.name = name;
		}
		public int getSalary() {
		return salary;
		}
		public void setSalary(int salary) {
		this.salary = salary;
		}
		public String getDesignation() {
		return designation;
		}
		public void setDesignation(String designation) {
		this.designation = designation;
		}
		public Employee()
		{
		}
		public Employee(int i,String n,int s,String d)
		{
		id=i;
		name=n;
		salary=s;
		designation=d;
		}
		public void display()
		{
		System.out.println("Id is: "+id);
		System.out.println("Name is: "+name);
		System.out.println("Salary is: "+salary);
		System.out.println("Designation is: "+designation);	

	}

}
