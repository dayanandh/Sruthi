import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;


public class Property1 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Properties prop = new Properties();
		FileReader fr = new FileReader("jdbc.properties");
		prop.load(fr);
		String Url=prop.getProperty("url");
		String Uname=prop.getProperty("uname");
		String Password = prop.getProperty("password");
		System.out.println(Url);
		System.out.println(Uname);
		System.out.println(Password);

	}

}
