import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;


public class dates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("enter date1");
        String input = sc.next();
        LocalDate date = LocalDate.parse(input,format);
        System.out.println("enter date2");
        String input2 = sc.next();
        LocalDate date2 = LocalDate.parse(input2,format);
        long diffInDays = ChronoUnit.DAYS.between(date,date2);
        System.out.println("days "+diffInDays);
	    long diffInMonths = ChronoUnit.MONTHS.between(date,date2);
	    System.out.println("months "+diffInMonths);
	    long diffInYears = ChronoUnit.YEARS.between(date,date2);
	    System.out.println("years "+diffInYears);
	}

}
