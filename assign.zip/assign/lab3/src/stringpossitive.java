import java.util.Scanner;

public class stringpossitive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    int cnt=0;
		System.out.println("enter a name");
		Scanner in = new Scanner(System.in);
        String  name = in.next();
        System.out.println("enterd name is: "+name);
        for(int i=1;i<name.length();i++){
        	char c = name.charAt(i-1);
        	char d = name.charAt(i);
        	if(c>d)
        	{
        		cnt = cnt+1;
        	}
        }
        if(cnt >= 1)
        {
        	System.out.println("neg");
        }
        else
        {
        	System.out.println("pos");
        }
       }
	}

	

	


