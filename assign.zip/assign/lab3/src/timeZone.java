import java.time.*;
import java.time.zone.ZoneRulesException;
import java.util.Scanner;
public class timeZone {

    public static void main(String[] args){
        try{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Zone Id");
        String Zone=sc.next();
        LocalDate zoneDate = LocalDate.now(ZoneId.of(Zone));
        System.out.println("zoneDate = "+zoneDate);
        LocalDateTime zonetime = LocalDateTime.now(ZoneId.of(Zone)); 
        System.out.println("zonetime = "+zonetime);
        }
        catch(ZoneRulesException e)
        {
            System.out.println("Enter correct zone id");
        }
    }

}
