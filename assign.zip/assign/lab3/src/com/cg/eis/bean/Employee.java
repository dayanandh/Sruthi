package com.cg.eis.bean;

public class Employee {

	int empid;
	String empName;
	int empsal;
	String empdesg;
	String inscheme;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpsal() {
		return empsal;
	}
	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}
	public String getEmpdesg() {
		return empdesg;
	}
	public void setEmpdesg(String empdesg) {
		this.empdesg = empdesg;
	}
	public String getInscheme() {
		return inscheme;
	}
	public void setInscheme(String inscheme) {
		this.inscheme = inscheme;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName
				+ ", empsal=" + empsal + ", empdesg=" + empdesg + ", inscheme="
				+ inscheme + "]";
	}
	
	
}
