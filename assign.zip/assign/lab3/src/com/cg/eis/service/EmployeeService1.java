package com.cg.eis.service;

public interface EmployeeService1 {

}
