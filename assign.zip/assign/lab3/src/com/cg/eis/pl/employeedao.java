package com.cg.eis.pl;

import java.util.Scanner;

public class employeedao {
	public static void main(String[] args){
		   System.out.println("employeeid");
		   Scanner sc = new Scanner(System.in);
	       int id = sc.nextInt();
	       System.out.println("employee name");
	       Scanner sc1 = new Scanner(System.in);
	       String empName = sc1.toString();
	       System.out.println("employee salary");
	       Scanner sc2 = new Scanner(System.in);
	       int sal = sc2.nextInt();
	       System.out.println("employee designation");
	       Scanner sc3 = new Scanner(System.in);
	       String desg = sc3.toString();
	       System.out.println("employee insurance scheme");
	       Scanner sc4 = new Scanner(System.in);
	       String insheme = sc4.toString();
		
		
}
}