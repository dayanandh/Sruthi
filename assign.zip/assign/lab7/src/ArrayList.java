import java.util.Arrays;


public class ArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arr[]={"Sony","LG","Apple","Moto"};
		Arrays.sort(arr);
		for(int i=0;i<arr.length;i++)
		{
		System.out.println(arr[i]);
		}

	}

}
