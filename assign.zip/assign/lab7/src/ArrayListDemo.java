import java.util.Collections;
import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList<>();
		list.add("Sony");
		list.add("Apple");
		list.add("LG");
		list.add("Moto");
		Collections.sort(list);
		for(String s:list)
		{
		System.out.println(s);
		}
	}

}
