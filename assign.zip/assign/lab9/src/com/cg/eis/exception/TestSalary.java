package com.cg.eis.exception;

import org.junit.Test;

import com.cg.eis.bean.Employee1;

public class TestSalary {
	@Test(expected=InvalidSalary.class)
	public void testSalaryException() throws InvalidSalary
	{
	Employee1 emp=new Employee1();
	boolean res=emp.sal1(2500);
	}
}
