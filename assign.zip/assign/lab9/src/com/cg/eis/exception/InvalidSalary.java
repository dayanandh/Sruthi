package com.cg.eis.exception;

public class InvalidSalary extends Exception{
	public InvalidSalary()
	{
	super("Invalid");
	}
	public InvalidSalary(String msg)
	{
	super(msg);
	}
}
