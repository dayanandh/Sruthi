package com.cg.eis.bean;

import java.util.Scanner;

import com.cg.eis.exception.InvalidSalary;

public class Employee1 {

	public static void main(String[] args) throws InvalidSalary {
		// TODO Auto-generated method stub
		Employee1 emp=new Employee1();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your salary");
		int sal=sc.nextInt();
		emp.sal1(sal);
		}
		public boolean sal1(int sal) throws InvalidSalary
		{
		try
		{
		if(sal>3000)
		return true;
		else
		throw new InvalidSalary("Error");
		}
		catch(InvalidSalary e)
		{
		throw new InvalidSalary(e.getMessage());
		}

	}

}
