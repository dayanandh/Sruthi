package com.xyz;

public class Person1 {
	String firstname;
	String lastname;
	char gender;
	public Person1()
	{
	}
	public Person1(String fn,String ln,char g)
	{
	firstname=fn;
	lastname=ln;
	gender=g;
	}
	public String getFirstname() {
	return firstname;
	}
	public void setFirstname(String firstname) {
	this.firstname = firstname;
	}
	public String getLastname() {
	return lastname;
	}
	public void setLastname(String lastname) {
	this.lastname = lastname;
	}
	public char getGender() {
	return gender;
	}
	public void setGender(char gender) {
	this.gender = gender;
	}
	public void display()
	{
	System.out.println("Firstname is "+firstname);
	System.out.println("Lastname is "+lastname);
	System.out.println("Gender is "+gender);
	}
	public static void main(String[] args)
	{
	Person1 p=new Person1("Ankur","Singanjude",'M');
	p.display();
	}
}
