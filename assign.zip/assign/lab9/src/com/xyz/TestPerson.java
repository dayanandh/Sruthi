package com.xyz;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestPerson {
	static Person1 p1;
	@BeforeClass

	public static void createObject()
	{
	//System.out.println("Craeting calc object...");
	//p1=new Person1();
	p1=new Person1("Ankur","Singanjude",'M');
	p1.display();
	}
	@Test
	public void testGetfName()
	{
	Assert.assertSame("Ankur", p1.getFirstname());
	}
	@Test
	public void testGetlName()
	{
	Assert.assertSame("Singanjude", p1.getLastname());
	}
	@Test
	public void testGetGender()
	{
	Assert.assertSame('M', p1.getGender());
	}

}
