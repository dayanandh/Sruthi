package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.EmployeeBean;

public interface IEmployeeService {
	public  String insuranceScheme(EmployeeBean bean);
	public String viewAllDetails(EmployeeBean bean);
	public String addEmployee(EmployeeBean bean);
}
