package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.EmployeeBean;

public class EmployeeServiceImpl implements IEmployeeService {

	@Override
	public String insuranceScheme(EmployeeBean bean) {
		if(bean.getSalary()>5000 && bean.getSalary()<20000 && bean.getDesignation().equals("System Associate"))
		{
			System.out.println("Insurance Scheme is:Scheme C");
		}
		if(bean.getSalary()>=20000 && bean.getSalary()<40000 && bean.getDesignation().equals("Programmer"))
		{
			System.out.println("Insurance Scheme is:Scheme B");
		}
		if(bean.getSalary()>=40000 && bean.getDesignation().equals("Manager"))
		{
			System.out.println("Insurance Scheme is:Scheme A");
		}
		if(bean.getSalary()<5000 && bean.getDesignation().equals("Clerk"))
		{
			System.out.println("Insurance Scheme is:No Scheme ");
		}
		
		return bean.getInsuranceScheme();
	}

	@Override
	public String viewAllDetails(EmployeeBean bean) {
		System.out.println("Employee Name="+bean.getEmployeeName());
		System.out.println("Employee Id="+bean.getEmployeeId());
		System.out.println("Employee Salary="+bean.getSalary());
		System.out.println("Employee Designation="+bean.getDesignation());
		return null;
	}

	@Override
	public String addEmployee(EmployeeBean bean) {
		bean.getEmployeeName();
		bean.getEmployeeId();
		bean.getSalary();
		bean.getDesignation();
		return null;
	}

	
	

	
	
	
}
