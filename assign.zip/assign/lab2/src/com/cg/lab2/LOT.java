package com.cg.assignment1;


public enum LOT {
   M,F;
}
