package com.cg.assignment1;

public class PersonDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Fname="Divya";
		String Lname="Bharathi";
		String G="F";
		int Age=20;
		float Wt=(float)85.5;
		System.out.println("Person Details");
		System.out.println("Firstname: "+Fname);
		System.out.println("Lastname: "+Lname);
		System.out.println("Gender: "+G);
		System.out.println("Age: "+Age);
		System.out.println("Weight: "+Wt);
		
		
		
		
		
		
	}

}
