package com.cg.assignment1;

import java.util.Scanner;


public class Enumeration {
         String firstname;
         String lastname;
         
         LOT lot;
         int age;
         int weight;
        public Enumeration(String firstname, String lastname, 
                LOT lot, int age,
                int weight) {
            super();
            this.firstname = firstname;
            this.lastname = lastname;
            this.lot = lot;
            this.age = age;
            this.weight = weight;
        }
        
        public String getFirstname() {
            return firstname;
        }
        public void setFirstname(String firstname) {
            this.firstname = firstname;
        }
        public String getLastname() {
            return lastname;
        }
        public void setLastname(String lastname) {
            this.lastname = lastname;
        }
        public LOT getLot() {
            return lot;
        }
        public void setLot(LOT lot) {
            this.lot = lot;
        }
        public int getAge() {
            return age;
        }
        public void setAge(int age) {
            this.age = age;
        }
        public int getWeight() {
            return weight;
        }
        public void setWeight(int weight) {
            this.weight = weight;
        }
        
        public static void main(String[] args) {
            // TODO Auto-generated method stub
            
            Enumeration obj=new Enumeration("Vineela","B",LOT.F,22,50);
            System.out.println(obj.getFirstname());
            System.out.println(obj.getLastname());
            System.out.println(obj.getLot());
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter phone no:");
            long phone_no=sc.nextLong();
            System.out.println("phone no:"+phone_no);
            System.out.println(obj.getAge());
            System.out.println(obj.getWeight());
        }
}



