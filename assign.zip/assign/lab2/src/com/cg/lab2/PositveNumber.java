package com.cg.assignment1;

public class PositveNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer num = Integer.parseInt(args[0]);
		if(num<0)
		{
			System.out.println("Given Number is Negative");
		}	
			else{
				System.out.println("Given Number is Positive");
			}
		
		
		
	}

}
