package com.cg.assignment1;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person str = new Person("Divya","Bharathi","F");
		System.out.println("Firstname:"+str.Firstname);
		System.out.println("Lastname:"+str.Lastname);
		System.out.println("gender:"+str.gender);
		Scanner sc = new Scanner(System.in);
		Person.display();
		
		
	}

}
