package com.cg.assignment1;

import java.util.Scanner;

public class Person {
	static String Firstname;
	String Lastname;
	String gender;
	Long mobileno;
	
	public static void display(){
		Long mobileno;
		Scanner sc = new Scanner(System.in);
		Firstname = sc.nextLine();
		System.out.println("Enter the mobile no :"+sc);
		
	}
	
	public Person(String firstname, String lastname, String gender) {
		super();
		this.Firstname = firstname;
		this.Lastname = lastname;
		this.gender = gender;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
}
