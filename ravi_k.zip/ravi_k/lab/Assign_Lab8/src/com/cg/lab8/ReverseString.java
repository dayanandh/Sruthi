package com.cg.lab8;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class ReverseString 
{
public static void main(String[] args) throws Exception {
	

	FileReader fr=new FileReader("Content.txt");
    BufferedReader br= new BufferedReader(fr);
    //Map<String,String> map=new HashMap<String,String>();
    //FileOutputStream out=new FileOutputStream("wrotelogin.txt");
    StringBuilder sb=new StringBuilder();
    ArrayList<String> a=new ArrayList<String>();
    while(br.ready())
    {
        StringBuilder sb1=new StringBuilder(br.readLine());
        sb1=sb1.reverse();
        a.add(sb1.toString());
            
    }
    PrintWriter out1=new PrintWriter("WriteContent.txt");
    for(int i=a.size()-1;i>=0;i--)
    {
        out1.write(a.get(i));
        out1.println();
    }
    out1.flush();
    out1.close();
}
}

