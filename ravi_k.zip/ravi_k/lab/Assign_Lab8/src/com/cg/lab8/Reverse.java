package com.cg.lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.PrintWriter;

public class Reverse 
{
	public static void main(String[] args) throws Exception
    {
        FileReader fr = new FileReader("Content.txt");
        LineNumberReader br = new LineNumberReader(fr);
        //BufferedReader br = new BufferedReader(fr);
        
        while(br.ready())
        {
           
            StringBuffer str  = new StringBuffer(br.readLine());
            
            
            str.reverse();
            System.out.println(str);
            String str1 = str.toString();
            PrintWriter out = new PrintWriter("Content.txt");
            out.write(str1);
            out.close();
            System.out.println(" Information Saved");
            //String str1 = str.
        }
       }

}
