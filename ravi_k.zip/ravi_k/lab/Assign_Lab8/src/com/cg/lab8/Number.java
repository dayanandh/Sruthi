package com.cg.lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Number 
{
		public static void main(String[] args)
		{
			File file=new File("numbers.txt");
			Scanner sc;
			try
			{
				sc = new Scanner(file).useDelimiter(",");
				while(sc.hasNext())
				{
					int c=sc.nextInt();
					if(c%2==0)
					System.out.println(c);
				}
			} 
			catch (FileNotFoundException e)
			{
			e.printStackTrace();
			}

		}
}
