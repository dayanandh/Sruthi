package com.cg.lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test
{
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		try
		{
		FileInputStream fis = new FileInputStream("8.1.txt");
		int ch;
		while((ch=fis.read())!=-1)
		{
		char chr = (char)ch;
		sb.append(chr);
		}
		fis.close();
		}catch(FileNotFoundException e){
		e.printStackTrace();
		}catch(IOException e)
		{
		e.printStackTrace();
		}
		int len = sb.length();
		try {
		FileOutputStream fos = new FileOutputStream("8.1.txt");
		for(int i=len-1;i>=0;i--){
		fos.write((char)sb.charAt(i));
		System.out.println();
		}
		fos.close();
		}catch(FileNotFoundException e){
		e.printStackTrace();
		}catch(IOException e){
		e.printStackTrace();
		}

	}

}
