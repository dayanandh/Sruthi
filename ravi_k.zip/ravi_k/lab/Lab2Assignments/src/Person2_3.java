
public class Person2_3
{

	    private String firstName;
	    private String lastName;
	    private Gender gender;
	    private String phoneNumber;
	    
	    
	    public Person2_3() {
	        super();
	    }
	    
	public Person2_3(String firstName, String lastName, Gender gender) {
	        super();
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.gender = gender;
	    }
	    public void setPhoneNumber(String phoneNumber) {
	         this.phoneNumber=phoneNumber;
	    }
	     
	    public String getPhoneNumber() {
	        return phoneNumber;
	    }
	    public void displayDetails()
	    {
	        System.out.println("First Name: "+firstName);
	        System.out.println("Last Name: "+lastName);
	        System.out.println("Gender: "+gender);
	        System.out.println("Phone Number: "+phoneNumber);
	    }
	    public String getFirstName() {
	        return firstName;
	    }
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    public String getLastName() {
	        return lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	    public Gender getGender() {
	        return gender;
	    }
	    public void setGender(Gender gender) {
	        this.gender = gender;
	    } 
	    
	    
	

}
