package com.cg.lab3;

public class Concat 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           String str1 = new String("harsha");
           String str2 = str1.concat(str1);
           System.out.println("string= "+str2);
           for(int i=0;i<=str1.length();i++){
        	   if(i%2!=0){
        		   str1=str1.substring(0,i-1) + "#" + str1.substring(i,str1.length());
        	   }
           }
	        System.out.println(str1);
	        String m = new String("raina");
	        for(int i=0;i<m.length();i++){
	        	   if(i%2!=0){
	        		   
	        		   String str3 = m.toUpperCase();
	        		   System.out.println(str3);
	        	   }
	           }
	       
	}

}
