package com.cg.lab3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Date 
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    LocalDate today = LocalDate.now();
        System.out.println("enter date");
        String input = sc.next();
        LocalDate date = LocalDate.parse(input,format);
        
        Period diff = today.until(date);
        System.out.println("difference = "+diff);
	}
}
