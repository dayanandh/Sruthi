package com.cg.mb.dao;

public interface IMobileDao
{

	
}
