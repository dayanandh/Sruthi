package com.cg.ps.service;

import java.util.List;

import com.cg.ps.bean.ProductBean;
import com.cg.ps.dao.IProductDao;
import com.cg.ps.dao.ProductDaoImpl;
import com.cg.ps.exception.ProductException;

public class ProductServiceImpl implements IProductService
{

	private IProductDao productDao = new ProductDaoImpl();
	@Override
	public int addProduct(ProductBean bean) throws ProductException
	{
		int id = productDao.addProduct(bean);
		return id;
	}

	@Override
	public ProductBean findProductById(int productId) throws ProductException 
	{
		ProductBean bean = productDao.findProductById(productId);
		
		return bean;
	}

	@Override
	public boolean validateProduct(ProductBean bean) throws ProductException 
	{
		
		return true;
	}

	@Override
	public ProductBean deleteProduct(int productId) throws ProductException 
	{
		ProductBean bean = productDao.deleteProduct(productId);
		
		return bean;
	}

	@Override
	public List<ProductBean> viewAllProducts() throws ProductException {
		List<ProductBean> bean1 = productDao.viewAllProducts();;
        //bean1 =productDao.viewAllProducts();
        return bean1;
	}


}
