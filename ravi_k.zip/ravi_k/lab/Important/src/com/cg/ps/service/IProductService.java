package com.cg.ps.service;

import java.util.List;

import com.cg.ps.bean.ProductBean;
import com.cg.ps.exception.ProductException;

public interface IProductService 
{

	public int addProduct(ProductBean bean) throws ProductException;
	public  ProductBean findProductById(int productId)throws ProductException;
	public boolean validateProduct(ProductBean bean) throws ProductException;
	
	public ProductBean deleteProduct(int productId) throws ProductException;
	public List<ProductBean> viewAllProducts() throws ProductException;
}
