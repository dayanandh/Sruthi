package com.cg.ps.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.ps.bean.ProductBean;
import com.cg.ps.exception.ProductException;

public class ProductDaoImpl implements IProductDao 
{
	private Map<Integer,ProductBean> map= new HashMap<Integer,ProductBean>();
	
	private static int productCounter = 1000;

	@Override
	public int addProduct(ProductBean bean) throws ProductException
	{
		if(productCounter < 0)
		{
			throw new ProductException("Product ID negtive");
		}
		
		productCounter++;
		bean.setProductId(productCounter);
		map.put(productCounter,bean);
		
		return productCounter;
	}

	@Override
	public ProductBean findProductById(int productId) throws ProductException
	{
		
		ProductBean bean= null;
		if(map.containsKey(productId))
		{
			bean= map.get(productId);
		}
		else
		{
			throw new ProductException("Product not Found ");
		}
		
		return bean;
	}
	
	@Override
	public ProductBean deleteProduct(int productId) throws ProductException {
		ProductBean b1= new ProductBean();
		if(map.containsKey(productId))
		{
			b1= map.remove(productId);
		}
		else
		{
			throw new ProductException("Product not Found ");
		}
		
		return b1;
		
	}

	@Override
	public List<ProductBean> viewAllProducts() throws ProductException {
		List<ProductBean> bean1=new ArrayList<ProductBean>();
        for(Map.Entry<Integer,ProductBean> entry : map.entrySet())
        {
            bean1.add(entry.getValue());
        }
        
        return bean1;
	}

}
