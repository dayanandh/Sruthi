package com.cg.ps.exception;

public class ProductException extends Exception
{

	public ProductException(String message)
	{
		super(message);
	}
}
