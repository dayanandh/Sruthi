package com.cg.ems.pl;

import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.service.EmployeeServiceImp1;
import com.cg.ems.service.IEmployeeService;

public class Client 
{

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Employee ID");
		int id=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Name");
		String name= scanner.nextLine();
		System.out.println("Enter Designation");
		String desig= scanner.nextLine();
		System.out.println("Enter mobile no");
		long mobile= Long.parseLong(scanner.nextLine());
		Employee emp=new Employee();
		emp.setEmployeeId(id);
		emp.setEmployeeName(name);
		emp.setEmployeeDesignation(desig);
		emp.setEmployeeMobile(mobile);
		IEmployeeService service =new EmployeeServiceImp1();
		
		if(service.validateEmployee(emp))
		{
			service.calculateSalary(emp);
			System.out.println("salary ="+emp.getEmployeeSalary());
		}
		else
		{
			System.out.println("Validation fails");
		}
		
	}
}
