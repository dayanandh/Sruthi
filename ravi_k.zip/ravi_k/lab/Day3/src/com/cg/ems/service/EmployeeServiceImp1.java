package com.cg.ems.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.bean.Employee;

public class EmployeeServiceImp1 implements IEmployeeService

{
	@Override
	public void calculateSalary(Employee bean)
	{
		
		String design=bean.getEmployeeDesignation();
		
		if(design.equals("Manager"))
		{
			bean.setEmployeeSalary(15000);
		}
		else if(design.equals("clerk"))
		{
			bean.setEmployeeSalary(10000);
		}
		else
		{
			bean.setEmployeeSalary(8000);
		}
		
		
	}

	@Override
	public boolean validateEmployee(Employee bean) 
	{
		
		if(validateName(bean.getEmployeeName())&&validateDesign(bean.getEmployeeDesignation())&&validateMobile(String.valueOf(bean.getEmployeeMobile())))
        {
            return true;
        }
        else
        {
            return false;
        }
    }


	public boolean validateName(String name)
	{
		
		String input= name;
        
        Pattern pattern = Pattern.compile("[A-Z][a-z]{1,15}");
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();

		
	}
	public boolean validateDesign(String desig)
	{
		String input= desig;
        
        Pattern pattern = Pattern.compile("[A-Z][a-z]{1,15}");
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();

	}
	public boolean validateMobile(String mobile)
	{
		String input= mobile;
        
        
        Pattern pattern = Pattern.compile("[1-9][0-9]{9}");
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();

	}
}
