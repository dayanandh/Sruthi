package com.cg.pk1;

public class Test {
	
	private int privateField;
	public int publicField;
	protected int protectedField;
	int defaultField;
	
	

}
