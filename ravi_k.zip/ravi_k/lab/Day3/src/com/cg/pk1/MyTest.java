package com.cg.pk1;

public class MyTest {
	
	public void display()
	{
		Test test= new Test();
		test.defaultField =10;
		test.protectedField =20;
		test.publicField =30;
		//test.privateField=90;
	}

}
