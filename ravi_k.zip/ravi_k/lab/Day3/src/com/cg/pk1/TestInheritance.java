package com.cg.pk1;

public class TestInheritance extends Test 
{
	
	public void display()
	{
		defaultField=10;
		publicField=90;
		protectedField=90;
		//privateField =100;
	}

}
