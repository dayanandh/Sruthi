package com.cg.demo;

public class Rectangle implements Shape
{

	@Override
	public void draw() {
		System.out.println("Rectangle draw");
		
	}

	@Override
	public void area() {
		System.out.println("Rectangle area");
		
	}

	
}
