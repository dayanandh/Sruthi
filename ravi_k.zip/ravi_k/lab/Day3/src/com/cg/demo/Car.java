package com.cg.demo;

public class Car extends Vehicle implements Shape
{

	@Override
	public void speed()
	{
		System.out.println("car speed");
		
	}
	
	@Override
	
	public void milage()
	{
		System.out.println("car milage");
		
	}
	
	public void startAc()
	{
		System.out.println("Ac started");
	}
	
	public void stopAc()
	{
		System.out.println("Ac Stopped");
	}

	@Override
	public void draw() {
		System.out.println("car draw");
		
	}

	@Override
	public void area() {
		System.out.println("car area");
		
	}
}
