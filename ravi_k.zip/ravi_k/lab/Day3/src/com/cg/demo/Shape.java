package com.cg.demo;

public interface Shape 

{	
	public double PI=3.142;
	public void draw();
	public abstract void area();
	
	default void display()
	{
		System.out.println("dispaly method called");
	}
	public static void show()
	{
		System.out.println("Show method called");
	}
	
}
