package com.cg.demo;

public class TestVehicle 
{
	
	public static void main(String[] args)
	{
		Vehicle vehicle=null;
		
		vehicle = new Car();
		vehicle.speed();
		vehicle.milage();
		
		vehicle = new Truck();
		vehicle.speed();
		vehicle.milage();
		
		
	}

}
