package com.cg.demo;

public class ShowRoom
{
	private Vehicle vehicle;
	public ShowRoom (Vehicle vehicle)
	{
		this.vehicle=vehicle;
	}
	public void display()
	{
		if(vehicle instanceof Car)
		{
			Car car=(Car) vehicle;
			vehicle.speed();
			car.startAc();
			car.stopAc();
		}
		else
		{
			vehicle.milage();
		}
	}
	
	
}
