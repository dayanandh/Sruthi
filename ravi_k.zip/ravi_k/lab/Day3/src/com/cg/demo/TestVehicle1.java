package com.cg.demo;

import java.util.Scanner;

public class TestVehicle1 
{
	
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter any number");
		int num=Integer.parseInt(scanner.nextLine());
		Vehicle vehicle=null;
		if(num%2==0)
		{
			vehicle =new Car();
		}
		else
		{
			vehicle =new Truck();
		}
		vehicle.speed();
	}
	
		
	

}
