package com.cg.demo;

public class TestShowRoom 
{
	public static void main(String[] args)
	{
		Car car=new Car();
		Truck truck=new Truck();
		ShowRoom sh =new ShowRoom(car);
		ShowRoom sh1 =new ShowRoom(truck);
		sh.display();
		sh1.display();
	}
}
