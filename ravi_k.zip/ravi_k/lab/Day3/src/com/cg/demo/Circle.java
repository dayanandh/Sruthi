package com.cg.demo;

public class Circle implements Shape
{

	@Override
	public void draw() {
		System.out.println("Circle draw");
		
	}

	@Override
	public void area() {
		System.out.println("circle area");
		
	}

}
