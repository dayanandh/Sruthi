package com.cg.demo;

import com.cg.exception.BalanceException;

public class TestAccount 
{
	public static void main(String[] args) 
	{
		Account account = new Account();
		
		try
		{
			account.deposit(10000);
			System.out.println(account);
			account.withdraw(50000);
			System.out.println(account);
		}
		catch(BalanceException e)
		{
			System.out.println( e.getMessage());
		}
	}
	
	
}
