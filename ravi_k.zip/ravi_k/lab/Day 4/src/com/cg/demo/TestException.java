package com.cg.demo;

public class TestException {

	public static void main(String[] args) 
	{
		try{
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
		
			int result = a/b;
			System.out.println(" Result = "+result);
		
			Palindrome palindrome = new Palindrome();
			String str = null;
			boolean flag = palindrome.isPalindrome(str);
			System.out.println(flag);
			}
		catch(ArithmeticException e)
		{
			//System.out.println( e.getMessage());
			e.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			//System.out.println( e.getMessage());
			e.printStackTrace();
		}
		catch(Exception e)
		{
			//System.out.println( e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			System.out.println("END OF PROGRAM");
		}
	}

}
