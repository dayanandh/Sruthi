package com.cg.demo;

import java.util.Arrays;

public class TestArray
{
	public static void main(String[] args)
	{
		int arr[]=new int[10];
		int [] arr1 =new int[10];
		
		int [] arr3 ={8,3,1,10,15,5,3,25,1,10};
		
		String [] str={"apple","orange","mango","strawberry"};
		
		for(int i=0;i<arr3.length;i++)
		{
			System.out.print(arr3[i]+" ");
		}
		System.out.println("\n *************************");
		for(int num: arr3)
		{
			System.out.print(num+" ");
			
		}
		
		Arrays.sort(arr3);// array sorting using Quick sort.
		System.out.println("\n after sorting");
		for(int num: arr3)
		{
			System.out.print(num+" ");
			
		}
		
		Arrays.fill(arr3,0);// filling tha values to zero for the arr3
		System.out.println("\n after filling");
		for(int num: arr3)
		{
			System.out.print(num+" ");
			
		}
		
		int i= Arrays.binarySearch(arr3,12);// binary searching i.e gives the negative value
		System.out.println("i= "+i);
		
	}

}
