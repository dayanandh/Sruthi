package com.cg.demo;

import java.util.Scanner;

public class TestExceptionResource 
{

	public static void main(String[] args) 
	{
		//Scanner scr = null;
		try(Scanner scr = new Scanner(System.in))// try block with resource
		{
		//Scanner scr = new Scanner(System.in);
		
		System.out.println("Roll Number ");
		int roll = Integer.parseInt(scr.nextLine());
		System.out.println(" Roll ="+roll);
		}
		
		/*finally
		{
		scr.close();
		}*/
	}

}
