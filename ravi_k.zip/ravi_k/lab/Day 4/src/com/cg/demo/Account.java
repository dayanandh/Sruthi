package com.cg.demo;

import com.cg.exception.BalanceException;

public class Account 
{
	private int balance;
	
	
	@Override
	public String toString() {
		return "Account [balance=" + balance + "]";
	}
	
	
	public void withdraw(int amount) throws BalanceException
	{
		if(balance<amount)
		{
			throw new BalanceException(" INSUFFICIENT BALANCE ");
		}
		balance = balance-amount;
	}
	public void deposit(int amount) throws BalanceException
	{
		if(amount > 50000)
		{
			throw new BalanceException(" AMOUNT TOO LARGE ");
		}
		balance += amount;
		
	}
}
