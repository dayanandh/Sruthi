package com.cg.demo;

import java.util.Arrays;

public class TestArray1
{
	   public static void sort(int mat[][])
	    {
	        int t=0;
	        for(int x=0; x<mat.length;x++)
	        {
	            for(int y=0;y<mat[x].length;y++)
	            {
	                for(int i=0; i<mat[y].length;i++)   
	                {
	                    for(int j=0; j<mat[i].length;j++)
	                    {
	                        if(mat[i][j]>mat[x][y])
	                        {
	                            t=mat[x][y];
	                            mat[x][y]=mat[i][j];
	                            mat[i][j]=t;
	                        }
	                    }
	                }
	            
	            }
	        }
	        
	    }

	    public static void main(String[] args) 
	    {
	        int mat[][] =  new int[3][3];
	        int [][] mat1 = { {8,2,3},{9,1,4},{18,12,10} };
	        
	        sort(mat1);
	        for(int i=0; i<mat1.length;i++)
	        {
	            for(int j=0;j<mat1[i].length;j++)
	            {
	                System.out.print(mat1[i][j]+" ");
	            }
	            System.out.println();
	        }
	        
	        
	    }

	}





