package com.cg.demo;

public class Palindrome 
{
	public boolean isPalindrome(String str)
	{
		boolean flag = true;
		int len = str.length();
		for(int i=0,j=len-1;i<=len/2;i++,j--)
		{
			if(str.charAt(i)!=str.charAt(j))
			{
				flag = false;
				break;
			}
		}
		return(flag);
	}
	
	
}
