package com.cg.demo;

import java.util.Scanner;

import com.cg.exception.BalanceException;

public class Client 
{

	public static void main(String[] args) 
	{
		int dep,wid,pb;
		Account account = new Account();
		Scanner scr = new Scanner(System.in);
		while(true)
		{	
			
			/*int a=scr.nextInt();
			int b=scr.nextInt();*/
			System.out.println(" 1.Deposit\n2.Withdraw\n3.Print Balance\n4.Exit\n");
			System.out.println("enter your Choice");
			int cho = scr.nextInt();
			switch(cho)
			{
				case 1 : 
						System.out.println("Enter the Amount you want to deposit");
						dep = scr.nextInt();
						try
						{
							account.deposit(dep);
							System.out.println(account);
						}
						catch(BalanceException e)
						{
							System.out.println( e.getMessage());
						}
						break;
						
				case 2 : 
					System.out.println("Enter the Amount you want to withdraw");
					wid = scr.nextInt();
					try
					{
						account.withdraw(wid);
						System.out.println(account);
					}
					catch(BalanceException e)
					{
						System.out.println( e.getMessage());
					}
					break;
				case 3 :
						System.out.println(account.toString());
						break;
				case 4:
						System.exit(0);
			}
		}
	}
}
	
				
				
				
	