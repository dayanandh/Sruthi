package com.cg.exception;

public class BalanceException extends Exception
{
	public BalanceException(String message)
	{
		super(message);
		
	}
}
