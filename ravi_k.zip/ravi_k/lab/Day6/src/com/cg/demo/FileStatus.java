package com.cg.demo;

import java.io.File;

public class FileStatus
{

	public static void main(String[] args) {
		
		//String fileName="sample.txt";
		// file is directory
		String fileName="C:/Windows";
		File file =new File(fileName);
		System.out.println("Exists : "+file.exists());
		System.out.println("Length : "+file.length());
		System.out.println("Directory : "+file.isDirectory());
		
		if(file.isDirectory())
		{
			String str[]=file.list();
			for(String s: str )
			{
				System.out.println(s);
			}
		}
	}
}
