package com.cg.demo;

import java.util.Properties;

public class TestProperties {

	public static void main(String[] args) {
		
		Properties prop=new Properties();
		
		prop.setProperty("john", "john123");
		prop.setProperty("amar", "amar123");
		prop.setProperty("radha", "radha123");
		
		prop.list(System.out);
		String str=prop.getProperty("john");
		System.out.println(str);
	}
}
