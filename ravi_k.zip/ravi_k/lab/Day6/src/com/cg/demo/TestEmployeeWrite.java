package com.cg.demo;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class TestEmployeeWrite 
{

	public static void main(String[] args) throws Exception
	 {
		
		Employee e1 = new Employee(1001,"John",9000);
		
		FileOutputStream fout = new FileOutputStream("emp.dat");
		ObjectOutputStream out = new ObjectOutputStream(fout);
		out.writeObject(e1);
		
		System.out.println("Object saved");
	}
}
