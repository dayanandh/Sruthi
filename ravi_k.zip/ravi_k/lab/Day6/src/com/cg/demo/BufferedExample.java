package com.cg.demo;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedExample
{

	public static void main(String[] args) {
		try{
			FileInputStream fin=new FileInputStream("sample.txt");
			BufferedInputStream bin =new BufferedInputStream(fin);
			// available is used in stream which displays all characters in the file through byte stream
			while(bin.available() > 0)
			{
				char ch=(char)bin.read();
				System.out.print(ch);
			}
		
		
		fin.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("file not found :"+e.getMessage());
		}
		catch(IOException e)
		{
			System.out.println("Read file :"+e.getMessage());
		}
	}

}
