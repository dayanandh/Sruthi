package com.cg.demo;

import java.io.PrintWriter;

public class TestFileWriter 
{
	public static void main(String[] args) throws Exception
	{
		
		int roll=1001;
		String name="Anil";
		double marks =89.67;
		PrintWriter out = new PrintWriter("student.txt");
		out.println(roll);
		out.println(name);
		out.println(marks);
		out.flush();
		out.close();
		System.out.println("information stored");
	}

}
