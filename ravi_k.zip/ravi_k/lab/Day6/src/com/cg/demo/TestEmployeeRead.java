package com.cg.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

public class TestEmployeeRead
{

	public static void main(String[] args) throws Exception {
		
		FileInputStream fin = new FileInputStream("emp.dat");
		ObjectInputStream oin = new ObjectInputStream(fin);
		
		Employee emp=(Employee)oin.readObject();
		System.out.println(emp);
	}
}
