package com.cg.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyFile
{

	public static void main(String[] args) {
		try{
			FileInputStream fin=new FileInputStream("sample.txt");
			FileOutputStream fout =new FileOutputStream("test.txt");
			// available is used in stream which displays all characters in the file through byte stream
			while(fin.available() > 0)
			{
				char ch=(char)fin.read();
				fout.write(fin.read());
				//System.out.print(ch);
			}
			fin.close();
			fout.close();
			System.out.println("file copied successfully");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("file not found :"+e.getMessage());
		}
		catch(IOException e)
		{
			System.out.println("Read file :"+e.getMessage());
		}
	}

}
