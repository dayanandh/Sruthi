package com.cg.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class BufferedExample1
{

	public static void main(String[] args) {
		try{
			FileReader fr=new FileReader("sample.txt");
			//ready returns true or false and displays all characters from the file
			//BufferedReader br = new BufferedReader(fr);
			
			//gets the line number
			LineNumberReader br = new LineNumberReader(fr);
			while(br.ready())
			{
				/*char ch=(char)br.read();
				System.out.print(ch);*/
				
				String str=br.readLine();
				//System.out.println(str);
				System.out.println(br.getLineNumber()+":"+str);
			}
		
		
		br.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("file not found :"+e.getMessage());
		}
		catch(IOException e)
		{
			System.out.println("Read file :"+e.getMessage());
		}
	}

}
