package com.cg.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DisplayFile1
{

	public static void main(String[] args) {
		try{
			FileReader fin=new FileReader("sample.txt");
			//ready returns true or false and displays all charcters from the file
			while(fin.ready())
			{
				char ch=(char)fin.read();
				System.out.print(ch);
			}
		
		
		fin.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("file not found :"+e.getMessage());
		}
		catch(IOException e)
		{
			System.out.println("Read file :"+e.getMessage());
		}
	}

}
