package com.cg.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

public class TestProp1 {

	public static void main(String[] args) throws Exception 
	{
		
		Properties prop = new Properties();
		FileReader fr=new FileReader("login.properties");
		//BufferedReader br = new BufferedReader(fr);
		prop.load(fr);
		//prop.list(System.out);
		
		String str=(String) prop.get("cjohn");
		if(str !=null)
		{
		System.out.println(str);
	
		}
	else
	{
		System.out.println("not found");
	}
}}
