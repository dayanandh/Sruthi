package com.cg.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

public class TestLogin 
{
	public static boolean verifyLoginProp(String user,String pass) throws Exception
	{
		boolean flag=false;
		Properties prop = new Properties();
		FileReader fr=new FileReader("login.properties");
		prop.load(fr);
		//prop.list(System.out);
		
		String str=(String) prop.get(user);
		if(str !=null)
		{
			System.out.println("password is "+str);
		}
		
	else
	{
		System.out.println("not found");
	}
		return (flag);
	}
	
	/*public static boolean verifyLoginMap(String user,String pass) throws Exception
	{
		boolean flag=true;
		try
		{
			FileReader fr=new FileReader("login.txt");
			BufferedReader br = new BufferedReader(fr);
			Map<String,String> map=new HashMap<String,String>();
			while(br.ready())
			{
			char ch=(char)br.read();
			System.out.print(ch);
			
			String[] str=br.readLine().split("=");
			//System.out.println(str);
	
			map.put(str[0], str[1]);
			}
			
			if(!map.containsKey(user))
			{
				flag=false;
			}
			else
			{
				String userpass=map.get(user);
				if(!userpass.equals(pass))
				{
					flag=false;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return (flag);
	}
*/
	/*public static boolean verifyLogin(String user,String pass) throws Exception
	{
		boolean flag=false;
		try
		{
			FileReader fr=new FileReader("login.txt");
			BufferedReader br = new BufferedReader(fr);
			while(br.ready())
			{
			char ch=(char)br.read();
			System.out.print(ch);
			
			String[] str=br.readLine().split("=");
			//System.out.println(str);
	
			if(str[0].equals(user) && str[1].equals(pass))
			{
				flag=true;
				break;
			}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return (flag);
	}*/
	public static void main(String[] args) throws Exception {
		
		Scanner scr =new Scanner(System.in);
		System.out.println("Enter login name");
		
		String user =scr.nextLine();
		System.out.println("Enter password");
		
		String pass=scr.nextLine();
		
		boolean flag = verifyLoginProp(user,pass);
		if( flag )
		{
			System.out.println("login success");
		}
		else
		{
			System.out.println("login failed");
		}
	}
}
