package com.cg.lab2;

import java.util.Enumeration;
import java.util.Scanner;

public class CreateEnumeration
{
	public static void main(String[] args) {
		Enumeration obj=new Enumeration("Divya","Bharathi",LOT.F,22  ,50);
        System.out.println(obj.getFirstname());
        System.out.println(obj.getLastname());
        System.out.println(obj.getLot());
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter phone no:");
        long phone_no=sc.nextLong();
        System.out.println("phone no:"+phone_no);
        System.out.println(obj.getAge());
        System.out.println(obj.getWeight());
    }
	}
}
