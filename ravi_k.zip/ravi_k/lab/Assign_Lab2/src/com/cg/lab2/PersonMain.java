package com.cg.lab2;

import java.util.Scanner;

public class PersonMain
{
	public static void main(String[] args)
	{
		Person str = new Person("Divya","Bharathi","F");
		System.out.println("Firstname:"+str.Firstname);
		System.out.println("Lastname:"+str.Lastname);
		System.out.println("gender:"+str.gender);
		Scanner sc = new Scanner(System.in);
		Person.display();
	}
}
