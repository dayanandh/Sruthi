package com.cg.lab2;

import java.util.Scanner;


public class Person 
{
	public static String Firstname;
	public String Lastname;
	public String gender;
	
	public Person(String firstname, String lastname, String gender) 
	{
		Firstname = firstname;
		Lastname = lastname;
		this.gender = gender;
	}

	public Person()
	{
		
	}

	public String getFirstname() {
		return Firstname;
	}

	public void setFirstname(String firstname) {
		Firstname = firstname;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Person [Firstname=" + Firstname + ", Lastname=" + Lastname
				+ ", gender=" + gender + "]";
	}

	public static void display() 
	{

		Long mobileno;
		Scanner sc = new Scanner(System.in);
		Firstname = sc.nextLine();
		System.out.println("Enter the mobile no :"+sc);
	}
	
	
	
	
	
}


