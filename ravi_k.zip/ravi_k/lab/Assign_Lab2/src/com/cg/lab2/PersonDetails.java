package com.cg.lab2;

public class PersonDetails
{
	public static void main(String[] args)
	{
	
		String firstName="Divya";
		String lastName="Bharathi";
		String gender="F";
		int Age=20;
		float weight=(float)85.55;
		
		System.out.println("Person Details");
		System.out.println("FirstName: "+firstName);
		System.out.println("LastName: "+lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+Age);
		System.out.println("Weight: "+weight);
	
	}
}
