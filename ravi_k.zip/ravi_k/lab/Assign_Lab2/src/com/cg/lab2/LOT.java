package com.cg.lab2;

public enum LOT {
	   M,F;
	}