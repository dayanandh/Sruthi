package com.cg.lab2;

import java.util.Enumeration;
import java.util.Scanner;

public class EnumerationImpl {

	String firstname;
    String lastname;
    
    LOT lot;
    int age;
    int weight;
   
       public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public LOT getLot() {
		return lot;
	}
	public void setLot(LOT lot) {
		this.lot = lot;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public Enumeration getObj() {
		return obj;
	}
	public void setObj(Enumeration obj) {
		this.obj = obj;
	}
	public Scanner getSc() {
		return sc;
	}
	public void setSc(Scanner sc) {
		this.sc = sc;
	}
	public long getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	Enumeration obj=new Enumeration("Vineela","B",LOT.F,22,50);
       System.out.println(obj.getFirstname());
       System.out.println(obj.getLastname());
       System.out.println(obj.getLot());
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter phone no:");
       long phone_no=sc.nextLong();
       System.out.println("phone no:"+phone_no);
       System.out.println(obj.getAge());
       System.out.println(obj.getWeight());
   }
}

}
