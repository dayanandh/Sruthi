package com.cg.lab2;

public class NumberCheck
{

	public static void main(String[] args) 
	{
		Integer num = Integer.parseInt(args[0]);
		if(num<0)
		{
			System.out.println("Given Number is Negative");
		}	
		else
		{
			System.out.println("Given Number is Positive");
		}
		
	}
}
