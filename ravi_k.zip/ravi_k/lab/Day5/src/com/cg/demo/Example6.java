package com.cg.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Example6 
{

	public static void print(Map<Integer,String> map)
	{
		Set<Entry<Integer,String>> set=map.entrySet();
		
		for(Entry<Integer,String> entry :set)
		{
			System.out.println(entry.getKey()+ " "+entry.getValue());
					
		}
	}
	public static void main(String[] args)
	{
		HashMap<Integer,String> map =new HashMap<Integer,String>();
		map.put(1003, "Ravi");
		map.put(1001, "David");
		map.put(1002, "Manoj");
		
		if(map.containsKey(1001))
		{
			String str=map.get(1001);
			//String str1=map.remove(1001);
			System.out.println(str);
			
		}
		else
		{
			System.out.println("not found");
		}
		
		System.out.println(map);
	}
}
