package com.cg.demo;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Example4 
{

	public static void printList(Collection<String> set)
	{
		
		for(String str :set)
		{
			System.out.print(str+" ");
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		/*ArrayList<String> list =new ArrayList<String>();
		System.out.println(list.isEmpty());*/
		
		/*LinkedList<String> list=new LinkedList<String>();*/
		
		/*Set<String> set=new TreeSet<String>();
		
		set.add("Mumabi");
		set.add("Bengaluru");
		set.add("hyd");
		printList(set);*/
		
		
		Set<String> set=new LinkedHashSet<String>();
		List<String> list = Arrays.asList("mango","orange","pineapple");
		set.add("Mumabi");
		set.add("Bengaluru");
		set.add("hyd");
		Collections.sort(list);
		printList(set);
		printList(list);
		
		
		
	}
}
