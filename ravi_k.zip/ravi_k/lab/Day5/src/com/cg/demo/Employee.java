package com.cg.demo;

public class Employee<T>
{

	
	private T employeeId;

	public T getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(T employeeId) {
		this.employeeId = employeeId;
	}
	
}
