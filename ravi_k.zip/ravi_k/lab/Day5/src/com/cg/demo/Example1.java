package com.cg.demo;

import java.util.ArrayList;

public class Example1
{

	public static void main(String[] args)
	{
		ArrayList<String> list =new ArrayList<String>();
		System.out.println(list.isEmpty());
		
		list.add("Mumabi");
		list.add("Bengaluru");
		list.add(1,"hyd");
		
		System.out.println(list);
		
		String str =list.get(1);
		System.out.println(str);
		
		
		int size=list.size();
		System.out.println(size);
	}
}
