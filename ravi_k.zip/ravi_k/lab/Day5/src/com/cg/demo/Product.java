package com.cg.demo;

public class Product implements Comparable<Product>
{

	private int productId;
	private String productName;
	private double productprice;
	
	public Product(int productId, String productName, double productprice) {
		
		this.productId = productId;
		this.productName = productName;
		this.productprice = productprice;
	}
	
	public Product() {
	
		this.productId = 0;
		this.productName = null;
		this.productprice = 0;
	}
	
	public int getProductId()
	{
		return productId;
	}
	
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductprice() {
		return productprice;
	}
	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", productprice=" + productprice + "]";
	}
	
	/*@Override
	public int compareTo(Product product)
	{
		int status = this.getProductId() - product.getProductId();
		return(status);
	}*/
	
	@Override
	public int compareTo(Product product)
	{
		
		return this.productName.compareTo(product.productName);
		
	}
}
