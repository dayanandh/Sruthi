package com.cg.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Example3
{
	public static void printList(List<String> list)
	{
		
		for(String str :list)
		{
			System.out.print(str+" ");
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		/*ArrayList<String> list =new ArrayList<String>();
		System.out.println(list.isEmpty());*/
		
		LinkedList<String> list=new LinkedList<String>();
		
		list.add("Mumabi");
		list.add("Bengaluru");
		list.add("hyd");
		printList(list);
		
		
		
		
	}
}
