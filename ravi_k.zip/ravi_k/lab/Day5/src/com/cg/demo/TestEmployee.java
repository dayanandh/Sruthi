package com.cg.demo;

public class TestEmployee 
{
	public static void main(String[] args) {
		
		Employee<Integer> e1=new Employee<Integer>();
		Employee<String> e2=new Employee<String>();
		e1.setEmployeeId(1001);
		
		int id= e1.getEmployeeId();
		System.out.println("ID = "+id);
		
		e2.setEmployeeId("AD1001");
		
		String empid = (String) e2.getEmployeeId();
		System.out.println(empid);
	}

}
