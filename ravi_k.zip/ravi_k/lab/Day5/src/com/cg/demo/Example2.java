package com.cg.demo;

import java.util.ArrayList;
import java.util.Iterator;

public class Example2 
{
	
	public static void printListLambda(ArrayList<String> list)
	{
		
		list.forEach(p-> System.out.print(p+" "));
	}
	public static void printListEnhanced(ArrayList<String> list)
	{
		
		for(String str :list)
		{
			System.out.print(str+" ");
		}
		System.out.println();
	}
	

	public static void printListIterator(ArrayList<String> list)
	{
		
		Iterator<String> iterator=list.iterator();
		
		while (iterator.hasNext())
		{
			String str=iterator.next();
			System.out.print(str+" ");
		}
		
		
	}
	public static void printList(ArrayList<String> list)
	{
		
		for(int i=0;i<list.size();i++)
		{
			String str=list.get(i);
			System.out.print(str+" ");
		}
		System.out.println();
	}
	public static void main(String[] args)
	{
		ArrayList<String> list =new ArrayList<String>();
		System.out.println(list.isEmpty());
		
		list.add("Mumabi");
		list.add("Bengaluru");
		list.add(1,"hyd");
		printListEnhanced(list);
		printList(list);
		printListIterator(list);
		printListLambda(list);
		
		
		
	}
}
