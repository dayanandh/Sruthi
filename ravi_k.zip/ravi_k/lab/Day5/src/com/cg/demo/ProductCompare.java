package com.cg.demo;

import java.util.Comparator;

public class ProductCompare implements Comparator<Product>
{
	

	@Override
	public int compare(Product o1,Product o2)
	{
		/* ascending order
		return o1.getProductId() - o2.getProductId();*/
		
		//descending order
		return o2.getProductId() - o1.getProductId();
	}
}
