package com.cg.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Example5
{
	public static void printList(List<Product> list)
	{
		
		for(Product product :list)
		{
			System.out.println(product);
		}
		System.out.println();
	}
	public static void main(String[] args) {
		
		List<Product> list=new ArrayList<Product>();
		
		Product p1=new Product(1003,"Mobile",20000);
		Product p2=new Product(1001,"TV",20000);
		Product p3=new Product(1002,"Laptop",50000);
		
		
		list.add(p1);
		list.add(p2);
		list.add(p3);
		
		// this sorts based on string 
		Collections.sort(list);
		printList(list);
		
		//descending order
		Collections.sort(list,new ProductCompare());
		printList(list);
		
		
		/*Product remove = list.remove(0);
		System.out.println(remove);*/
	
	}
}
