import java.util.Scanner;


public class TestPalindrome {

	public static boolean isPalindrome(String str) 
	{
		boolean flag= true;
		
		return(flag);

	}
	public static void main(String[] args) {
		
		Scanner scr =new Scanner(System.in);
		System.out.println("Enter any string ");
		String str = scr.next();
		boolean flag = isPalindrome(str);
		if (flag)
		{
			System.out.println("string is palindrome ");
		}
		else
		{
			System.out.println(" not a palindrome");
		}
		
	}

}
