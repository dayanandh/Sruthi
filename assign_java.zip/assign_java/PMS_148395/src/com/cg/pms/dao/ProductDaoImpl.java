package com.cg.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.exception.ProductException;
import com.cg.pms.util.DBConnection;

public class ProductDaoImpl implements IProductDao
{

	@Override
	public int addProduct(ProductBean bean) throws ProductException {
		int productId=0;
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QuerryMapper.INSERT_QRY);
			pstmt.setString(1, bean.getProductName());
			pstmt.setDouble(2,bean.getProductPrice());
			int status = pstmt.executeUpdate();
			
			if(status > 0)
			{
				pstmt = con.prepareStatement(QuerryMapper.SEQUENCE_QRY);
				
				ResultSet rst =pstmt.executeQuery();
				
				if(rst.next())
				{
					productId = rst.getInt(1);
				}
				else
				{
					throw new ProductException("Faied to get values from sequence");
				
				}
			}
			else
			{
				throw new ProductException("Faied to insert product");
			}
		} catch (SQLException e)
		{
			
			throw new ProductException(e.toString());
		}
		
		return productId;
	}

	@Override
	public ProductBean findProductById(int productId) throws ProductException {
		ProductBean bean=null;
		
		
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QuerryMapper.SEARCH_QRY);
			
			pstmt.setInt(1, productId);
			ResultSet rst = pstmt.executeQuery();
			
			if( rst.next())
			{
				bean = new ProductBean();
				bean.setProductId(rst.getInt("productid"));
				bean.setProductName(rst.getString("productname"));
				bean.setProductPrice(rst.getDouble("productprice"));
			}
			else
			{
				throw new ProductException("product not found");
			}
		} catch (SQLException e)
		{
			
			throw new ProductException(e.toString());
		}
		
		
		return bean;
	}

	@Override
	public ProductBean deleteProduct(int productId) throws ProductException {
		ProductBean bean=findProductById(productId);
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QuerryMapper.DELETE_QRY);
			pstmt.setInt(1, productId);
			int status= pstmt.executeUpdate();
			if( status > 0)
			{
				/*bean = new ProductBean();
				bean.setProductId(status.getInt("productid"));*/
				System.out.println("Delete success"+bean);
			}
			else
			{
				throw new ProductException("unable to find the product id");
			}
			con.close();
		} catch (SQLException e)
		{
			
			throw new ProductException(e.toString());
		}
		
		
		return bean;
	}

	@Override
	public List<ProductBean> viewAllProducts() throws ProductException
	{
		List<ProductBean> bean1 = new ArrayList<ProductBean>();
		ProductBean bean= null;
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QuerryMapper.VIEW_QRY);
			ResultSet rst = pstmt.executeQuery();
			
				
			while( rst.next())
			{
				bean = new ProductBean();
				bean.setProductId(rst.getInt("productid"));
				bean.setProductName(rst.getString("productname"));
				bean.setProductPrice(rst.getInt("productprice"));
				bean1.add(bean);
				
			}
			con.close();
		} catch (SQLException e) 
		{
			
			throw new ProductException(e.toString());
		}
		return bean1;
	}

}
