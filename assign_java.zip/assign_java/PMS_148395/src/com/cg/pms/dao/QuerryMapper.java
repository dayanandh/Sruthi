package com.cg.pms.dao;

public interface QuerryMapper 
{

	public static final String INSERT_QRY="insert into product_tbl values(product_seq.nextval,?,?)";
	
	public static final String SEARCH_QRY="select productid,productname,productprice from product_tbl where productid=?";
	
	public static final String SEQUENCE_QRY="select product_seq.currval from dual";
	
	public static final String DELETE_QRY="delete from product_tbl where productid=?";
	
	public static final String VIEW_QRY="select productid,productname,productprice from product_tbl";
}
