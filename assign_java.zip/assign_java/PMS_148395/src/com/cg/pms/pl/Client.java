package com.cg.pms.pl;


import java.util.List;
import java.util.Scanner;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.exception.ProductException;
import com.cg.pms.service.IProductService;
import com.cg.pms.service.ProductServiceImpl;


public class Client 
{

	public static void main(String[] args) 
	{
		
		Scanner scanner= new Scanner(System.in);
		ProductBean bean = new ProductBean();
		
		IProductService service = new ProductServiceImpl();
		
		while(true)
		{
			System.out.println("1.ADD product");
			System.out.println("2.find product");
			System.out.println("3.delete the product");
			System.out.println("4.list the products");
			System.out.println("5. exit");
			System.out.println("Enter your choice");
			
			int choice = Integer.parseInt(scanner.nextLine());
			
			switch(choice)
			{
			case 1 : System.out.println("Enter Product name");
						String name = scanner.nextLine();
						System.out.println("Enter Product price");
						double price =Double.parseDouble(scanner.nextLine());
						bean = new ProductBean();
						bean.setProductName(name);
						bean.setProductPrice(price);
						try
						{
							
						if( service.validateProduct(bean))
						{
							int id = service.addProduct(bean);
							System.out.println("Added Successfully");
							System.out.println("ID = "+id);
						}}
						catch(ProductException e)
						{
							System.out.println(e.getMessage());
						}
						break;
			case 2 : System.out.println("Enter Product ID");
						int pid = Integer.parseInt(scanner.nextLine());
						try
						{
						bean = service.findProductById(pid);
						System.out.println("product found");
						System.out.println(bean);
						}
						catch(ProductException e)
						{
							System.out.println(e.getMessage());
						}
						break;
			case 3 : System.out.println("Enter the productId to be deleted");
						int pid1 = Integer.parseInt(scanner.nextLine());
						try
							{
								bean = service.deleteProduct(pid1);
								System.out.println("product deleted");
								System.out.println(bean);
							}
							catch(ProductException e)
							{
								System.out.println(e.getMessage());
							}
							break;
			case 4 :List<ProductBean> bean1;
            		try{
            			bean1=service.viewAllProducts();
            			System.out.println(bean1);
            			}
            		catch(ProductException e)
            		{
            			e.printStackTrace();
            		}
            		break;

			
			case 5 : System.out.println("Thank you");
						System.exit(0);
						
			default : System.out.println("Invalid choice");
			
			}
		}
		
	}
}
