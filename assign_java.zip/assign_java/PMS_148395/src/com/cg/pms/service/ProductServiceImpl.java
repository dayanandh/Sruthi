package com.cg.pms.service;

import java.util.List;

import com.cg.pms.bean.ProductBean;
import com.cg.pms.dao.IProductDao;
import com.cg.pms.dao.ProductDaoImpl;
import com.cg.pms.exception.ProductException;

public class ProductServiceImpl implements IProductService
{

	private IProductDao productDao = new ProductDaoImpl();
	
	public int addProduct(ProductBean bean) throws ProductException
	{
		int id = productDao.addProduct(bean);
		return id;
	}

	@Override
	public ProductBean findProductById(int productId) throws ProductException 
	{
		ProductBean bean = productDao.findProductById(productId);
		
		return bean;
	}

	@Override
	public boolean validateProduct(ProductBean bean) throws ProductException 
	{
		
		return true;
	}

	@Override
	public ProductBean deleteProduct(int productId) throws ProductException 
	{
		ProductBean bean = productDao.deleteProduct(productId);
		
		return bean;
	}

	@Override
	public List<ProductBean> viewAllProducts() throws ProductException {
		List<ProductBean> bean1 = productDao.viewAllProducts();;
        //bean1 =productDao.viewAllProducts();
        return bean1;
	}

	

}
