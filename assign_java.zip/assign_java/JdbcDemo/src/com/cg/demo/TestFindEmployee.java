package com.cg.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.util.DBConnection;

public class TestFindEmployee 
{
	public static void main(String[] args)
	{
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter empid");
		int empid = Integer.parseInt(scr.nextLine());
		
		
		Connection con = DBConnection.getConnection();
		String qry = QueryMapper.SEARCH_QRY; 
		try{
		PreparedStatement pstmt = con.prepareStatement(qry);
		pstmt.setInt(1,empid);
		
		
		ResultSet rst= pstmt.executeQuery();
		
		if(rst.next())
		{
			String name=rst.getString("empname");
			int salary=rst.getInt("empsalary");
			
			System.out.println(name+" "+salary);
		}
		else
		{
			System.out.println("id not found");
		}
		
		con.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}


}
