package com.cg.demo;

public interface QueryMapper
{

	public static final String  SEARCH_QRY="select empname,empsalary from employee_tb1 where empid=?";
	
	public static final String DELETE_QRY="delete from employee_tb1 where empid=?";
}

