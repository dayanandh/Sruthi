package com.cg.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.util.DBConnection;

public class DisplayAllRecord {
public static void main(String[] args) {
		
		
		try
		{
		
		Connection con=DBConnection.getConnection();
		String qry="select empid,empname,empsalary from employee_tb1";
		
		Statement stmt = con.createStatement();
		ResultSet rst = stmt.executeQuery(qry);
		
		while( rst.next())
		{
			int id = rst.getInt("empid");
			String name=rst.getString("empname");
			int salary=rst.getInt("empsalary");
			System.out.println(id+ " "+name+ " "+salary);
		}
		con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		
	}

}
