package com.cg.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.util.DBConnection;

public class TestInsert {

	public static void main(String[] args)
	{
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter empid");
		int empid = Integer.parseInt(scr.nextLine());
		System.out.println("Enter empname");
		String empname = scr.nextLine();
		System.out.println("Enter empsalary");
		int empsalary = Integer.parseInt(scr.nextLine());
		
		Connection con = DBConnection.getConnection();
		String qry = "insert into employee_tb1(empid,empname,empsalary) values(?,?,?)"; //parameterised statement bcz ?
		try{
		PreparedStatement pstmt = con.prepareStatement(qry);
		pstmt.setInt(1,empid);
		pstmt.setString(2,empname);
		pstmt.setInt(3,empsalary);
		
		int status= pstmt.executeUpdate();
		
		if(status>0)
		{
			System.out.println("Insert success"+status);
		}
		else
		{
			System.out.println("insert fail");
		}
		
		con.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
