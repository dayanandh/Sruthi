package com.cg.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {

	public static void main(String[] args) {
		
		String driver="oracle.jdbc.driver.OracleDriver";
		String jdbcurl="jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
		String user="Lab01trg7";
		String pass="lab01oracle";
		try
		{
			
		Class.forName(driver); // load and register
		
		Connection con=DriverManager.getConnection(jdbcurl, user, pass);
		
		System.out.println("connection Success");
		
		con.close();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		
	}

}
