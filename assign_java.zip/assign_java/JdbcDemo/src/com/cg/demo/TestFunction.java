package com.cg.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.cg.util.DBConnection;

public class TestFunction 
{

public static void main(String[] args) {
		
		Connection con = DBConnection.getConnection();
		String qry="{ ?=call searchEmployee(?)}";
		
		try {
			CallableStatement cstmt = con.prepareCall(qry);
			
			cstmt.registerOutParameter(1, Types.VARCHAR);
			
			cstmt.setInt(2,  5000);
			
			cstmt.executeUpdate();
			
			String name = cstmt.getString(1);
			System.out.println("name="+name);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
