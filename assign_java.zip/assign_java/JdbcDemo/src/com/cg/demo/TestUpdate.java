package com.cg.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.util.DBConnection;

public class TestUpdate 
{

	public static void main(String[] args)
	{
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter empid");
		int empid = Integer.parseInt(scr.nextLine());
		System.out.println("Enter empname to update");
		String empname = scr.nextLine();
		System.out.println("Enter empsalary to update");
		int empsalary = Integer.parseInt(scr.nextLine());
		
		Connection con = DBConnection.getConnection();
		String qry = "update employee_tb1 set empname=?,empsalary=? where empid=?"; //parameterised statement bcz ?
		try{
		PreparedStatement pstmt = con.prepareStatement(qry);
		pstmt.setInt(3,empid);
		pstmt.setString(1,empname);
		pstmt.setInt(2,empsalary);
		
		int status= pstmt.executeUpdate();
		
		if(status>0)
		{
			System.out.println("update success"+status);
		}
		else
		{
			System.out.println("update fail bcz empid doesnt exist");
		}
		
		con.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
