package com.cg.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.cg.util.DBConnection;

public class TestProcedure {

	public static void main(String[] args) {
		
		Connection con = DBConnection.getConnection();
		String qry="{ call findEmployee(?,?)}";
		
		try {
			CallableStatement cstmt = con.prepareCall(qry);
			
			cstmt.registerOutParameter(2, Types.VARCHAR);
			
			cstmt.setInt(1,  50000);
			
			cstmt.executeUpdate();
			
			String name = cstmt.getString(2);
			System.out.println("name="+name);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
