package com.cg.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.util.DBConnection;

public class TestDelete 
{
	public static void main(String[] args)
	{
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter empid to delete");
		int empid = Integer.parseInt(scr.nextLine());
		/*System.out.println("Enter empname");
		String empname = scr.nextLine();
		System.out.println("Enter empsalary");
		int empsalary = Integer.parseInt(scr.nextLine());*/
		
		Connection con = DBConnection.getConnection();
		String qry = QueryMapper.DELETE_QRY;
		try{
		PreparedStatement pstmt = con.prepareStatement(qry);
		pstmt.setInt(1,empid);
		/*pstmt.setString(2,empname);
		pstmt.setInt(3,empsalary);*/
		
		int status= pstmt.executeUpdate();
		
		if(status>0)
		{
			System.out.println("Delete success"+status);
		}
		else
		{
			System.out.println("delete fail bcz id not found");
		}
		
		con.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}


}
